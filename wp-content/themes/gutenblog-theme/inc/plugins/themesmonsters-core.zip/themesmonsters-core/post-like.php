<?php
/*
Name:  WordPress Post Like System
Description:  A simple and efficient post like system for WordPress.
Version:      0.5.2
Author:       Jon Masterson
Author URI:   http://jonmasterson.com/
License:
Copyright (C) 2015 Jon Masterson
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * Register the stylesheets for the public-facing side of the site.
 * @since    0.5
 */
add_action( 'wp_enqueue_scripts', 'sl_enqueue_scripts' );
function sl_enqueue_scripts() {
	wp_enqueue_style('themesmonsters-front-css', plugin_dir_url( __FILE__ ) . 'assets/css/themesmonsters-front.css', false, '1.0', 'all');
	wp_enqueue_script( 'simple-likes-public-js', plugin_dir_url( __FILE__ ) . 'assets/js/simple-likes-public.js', array( 'jquery' ), '0.5', false );

	wp_localize_script( 'simple-likes-public-js', 'simpleLikes', array(
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'like' => __( 'Like', 'themes-monsters' ),
		'unlike' => __( 'Unlike', 'themes-monsters' ),
		'rating_plus' => __( 'Plus Rating', 'themes-monsters' ),
		'rating_minus' => __( 'Minus Rating', 'themes-monsters' )
	) ); 

}

/**
 * Process Rating Change Plus
 * @since    0.5
 */
add_action( 'wp_ajax_nopriv_process_rating_change_plus', 'process_rating_change_plus' );
add_action( 'wp_ajax_process_rating_change_plus', 'process_rating_change_plus' );
function process_rating_change_plus() {
	// Security
	$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : 0;
	if ( !wp_verify_nonce( $nonce, 'rating-change-nonce' ) ) {
		exit( __( 'Not permitted', 'themes-monsters' ) );
	}
	// Test if javascript is disabled
	$disabled = ( isset( $_REQUEST['disabled'] ) && $_REQUEST['disabled'] == true ) ? true : false;
	// Test if this is a comment
	$is_comment = ( isset( $_REQUEST['is_comment'] ) && $_REQUEST['is_comment'] == 1 ) ? 1 : 0;
	$response['is_comment'] = $is_comment;
	// Logged In
	$rating_loggedin = ( isset( $_REQUEST['loggedin'] ) && !empty($_REQUEST['loggedin']) ) ? $_REQUEST['loggedin'] : false;
	// Base variables
	$post_id = ( isset( $_REQUEST['post_id'] ) && is_numeric( $_REQUEST['post_id'] ) ) ? $_REQUEST['post_id'] : '';
	$result = array();
	$post_users = NULL;
	$rating_count = 0;
	$count_minus_double = false;
	// Get plugin options
	if ( $post_id != '' ) {

		$count = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_comment_rating_count", true ) : get_post_meta( $post_id, "_post_rating_count", true ); // rating count

		$count = ( isset( $count ) && is_numeric( $count ) ) ? $count : 0;

		$response['already_rating'] = already_rating_test( $post_id, $is_comment, 'plus', $rating_loggedin );
		$response['already_rating_t'] = 'plus';

		if ( !already_rating( $post_id, $is_comment, 'plus', $rating_loggedin ) ) { // rating the post
			if ( is_user_logged_in() ) { // user is logged in
				$user_id = get_current_user_id();

				// if rating was before to make sure to make -2 or -1 for $count
				$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_minus" ) : get_post_meta( $post_id, "_user_rating_minus" );
				if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
					$change_value_minus = $change_value_minus[0];
				}
				if ( in_array( $user_id, $change_value_minus ) ) {
					$count_minus_double = true;
				}

				$post_users_minus = post_user_rating_change_delete( $user_id, $post_id, $is_comment, 'minus' );
				$response['post_users_minus'] = $post_users_minus;



				$post_users_plus = post_user_rating_change( $user_id, $post_id, $is_comment, 'plus' );
				$response['post_users_plus'] = $post_users_plus;

				if ( $is_comment == 1 ) {
					// Update User & Comment
					$user_rating_count = get_user_option( "_comment_rating_count", $user_id );
					$user_rating_count =  ( isset( $user_rating_count ) && is_numeric( $user_rating_count ) ) ? $user_rating_count : 0;

					update_user_option( $user_id, "_comment_rating_count", ++$user_rating_count );
					
					// after delete update
					update_comment_meta( $post_id, "_user_comment_rating_minus", $post_users_minus );
					$response['post_meta_minus_new_comment'] = get_post_meta( $post_id, "_user_rating_minus" );

					// after update update
					if ( $post_users_plus ) {
						update_comment_meta( $post_id, "_user_comment_rating_plus", $post_users_plus );
					}
				} else {
					// Update User & Post
					$user_rating_count = get_user_option( "_user_rating_count", $user_id );
					$user_rating_count =  ( isset( $user_rating_count ) && is_numeric( $user_rating_count ) ) ? $user_rating_count : 0;

					update_user_option( $user_id, "_user_rating_count", ++$user_rating_count );
					
					// after delete update
					update_post_meta( $post_id, "_user_rating_minus", $post_users_minus );
					$response['post_meta_minus_new'] = get_post_meta( $post_id, "_user_rating_minus" );
					
					// after update update
					if ( $post_users_plus ) {
						update_post_meta( $post_id, "_user_rating_plus", $post_users_plus );
					}
				}
			} else { // user is anonymous
				$user_ip = sl_get_ip();

				// if rating was before to make sure to make -2 or -1 for $count
				$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_minus" ) : get_post_meta( $post_id, "_user_IP_rating_minus" );
				if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
					$change_value_minus = $change_value_minus[0];
				}
				if ( in_array( $user_ip, $change_value_minus ) ) {
					$count_minus_double = true;
				}

				$post_users_minus = post_ip_rating_change_delete( $user_ip, $post_id, $is_comment, 'minus' );
				$response['post_users_minus'] = $post_users_minus;

				$post_users_plus = post_ip_rating_change( $user_ip, $post_id, $is_comment, 'plus' );
				$response['post_users_plus'] = $post_users_plus;

				// Update Post
				if ( $is_comment == 1 ) {

					// after delete update
					update_comment_meta( $post_id, "_user_comment_IP_rating_minus", $post_users_minus );
					$response['post_meta_minus_new_IP_comment'] = get_post_meta( $post_id, "_user_comment_IP_rating_minus" );

					// after update update
					if ( $post_users_plus ) {
						update_comment_meta( $post_id, "_user_comment_IP_rating_plus", $post_users_plus );
					}
				} else { 

					// after delete update
					update_post_meta( $post_id, "_user_IP_rating_minus", $post_users_minus );
					$response['post_meta_minus_new_IP'] = get_post_meta( $post_id, "_user_IP_rating_minus" );

					// after update update
					if ( $post_users_plus ) {
						update_post_meta( $post_id, "_user_IP_rating_plus", $post_users_plus );
					}
				}
				
			}

			$response['count_minus_double'] = $count_minus_double;
			if($count_minus_double == true){
				$rating_count = ++$count;
				$rating_count = ++$count;
			} else if($count_minus_double == false){
				$rating_count = ++$count;
			}
			
			$response['status'] = "rating_plus";
			$response['icon'] = get_rating_plus_icon();


			if ( $is_comment == 1 ) {
				update_comment_meta( $post_id, "_comment_rating_count", $rating_count );
				update_comment_meta( $post_id, "_comment_rating_modified", date( 'Y-m-d H:i:s' ) );
			} else { 
				update_post_meta( $post_id, "_post_rating_count", $rating_count );
				update_post_meta( $post_id, "_post_rating_modified", date( 'Y-m-d H:i:s' ) );
			}
			$response['count'] = get_rating_count( $rating_count );
			$response['testing'] = $is_comment;

		} 
		
		if ( $disabled == true ) {
			if ( $is_comment == 1 ) {
				wp_redirect( get_permalink( get_the_ID() ) );
				exit();
			} else {
				wp_redirect( get_permalink( $post_id ) );
				exit();
			}
		} else {
			wp_send_json( $response );
		}
	}
}

/**
 * Process Rating Change Plus
 * @since    0.5
 */
add_action( 'wp_ajax_nopriv_process_rating_change_minus', 'process_rating_change_minus' );
add_action( 'wp_ajax_process_rating_change_minus', 'process_rating_change_minus' );
function process_rating_change_minus() {
	// Security
	$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : 0;
	if ( !wp_verify_nonce( $nonce, 'rating-change-nonce' ) ) {
		exit( __( 'Not permitted', 'themes-monsters' ) );
	}
	// Test if javascript is disabled
	$disabled = ( isset( $_REQUEST['disabled'] ) && $_REQUEST['disabled'] == true ) ? true : false;
	// Test if this is a comment
	$is_comment = ( isset( $_REQUEST['is_comment'] ) && $_REQUEST['is_comment'] == 1 ) ? 1 : 0;
	$response['is_comment'] = $is_comment;
	// Logged In
	$rating_loggedin = ( isset( $_REQUEST['loggedin'] ) && !empty($_REQUEST['loggedin']) ) ? $_REQUEST['loggedin'] : false;
	// Base variables
	$post_id = ( isset( $_REQUEST['post_id'] ) && is_numeric( $_REQUEST['post_id'] ) ) ? $_REQUEST['post_id'] : '';
	$result = array();
	$post_users = NULL;
	$rating_count = 0;
	$count_plus_double = false;
	// Get plugin options
	if ( $post_id != '' ) {

		$count = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_comment_rating_count", true ) : get_post_meta( $post_id, "_post_rating_count", true ); // rating count

		$count = ( isset( $count ) && is_numeric( $count ) ) ? $count : 0;

		$response['already_rating'] = already_rating_test( $post_id, $is_comment, 'minus', $rating_loggedin );
		$response['already_rating_t'] = 'minus';

		if ( !already_rating( $post_id, $is_comment, 'minus', $rating_loggedin ) ) { // no rating is set/ minus rating create new meta fields
			if ( is_user_logged_in() ) { // user is logged in
				$user_id = get_current_user_id();

				// if rating was before to make sure to make -2 or -1 for $count
				$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_plus" ) : get_post_meta( $post_id, "_user_rating_plus" );
				if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
					$change_value_plus = $change_value_plus[0];
				}
				if ( in_array( $user_id, $change_value_plus ) ) {
					$count_plus_double = true;
				}

				$post_users_minus = post_user_rating_change( $user_id, $post_id, $is_comment, 'minus' );
				$response['post_users_minus'] = $post_users_minus;

				$post_users_plus = post_user_rating_change_delete( $user_id, $post_id, $is_comment, 'plus' );
				$response['post_users_plus'] = $post_users_plus;

				if ( $is_comment == 1 ) {
					// Update User & Comment
					$user_rating_count = get_user_option( "_comment_rating_count", $user_id );
					$user_rating_count =  ( isset( $user_rating_count ) && is_numeric( $user_rating_count ) ) ? $user_rating_count : 0;

					update_user_option( $user_id, "_comment_rating_count", --$user_rating_count ); // --

					if ( $post_users_minus ) {
						update_comment_meta( $post_id, "_user_comment_rating_minus", $post_users_minus );
					}
					
					update_comment_meta( $post_id, "_user_comment_rating_plus", $post_users_plus );
					$response['post_meta_plus_new_comment'] = get_post_meta( $post_id, "_user_comment_rating_plus" );
				} else {
					// Update User & Post
					$user_rating_count = get_user_option( "_user_rating_count", $user_id );
					$user_rating_count =  ( isset( $user_rating_count ) && is_numeric( $user_rating_count ) ) ? $user_rating_count : 0;

					update_user_option( $user_id, "_user_rating_count", --$user_rating_count );// --

					if ( $post_users_minus ) {
						update_post_meta( $post_id, "_user_rating_minus", $post_users_minus );
					}

					update_post_meta( $post_id, "_user_rating_plus", $post_users_plus );
					$response['post_meta_plus_new'] = get_post_meta( $post_id, "_user_rating_plus" );
					
				}
			} else { // user is anonymous
				$user_ip = sl_get_ip();

				// if rating was before to make sure to make -2 or -1 for $count
				$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_plus" ) : get_post_meta( $post_id, "_user_IP_rating_plus" );
				if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
					$change_value_plus = $change_value_plus[0];
				}
				if ( in_array( $user_ip, $change_value_plus ) ) {
					$count_plus_double = true;
				}

				$post_users_minus = post_ip_rating_change( $user_ip, $post_id, $is_comment, 'minus' );
				$response['post_users_minus'] = $post_users_minus;

				$post_users_plus = post_ip_rating_change_delete( $user_ip, $post_id, $is_comment, 'plus' );
				$response['post_users_plus'] = $post_users_plus;

				// Update Post
				if ( $is_comment == 1 ) {

					// after delete update
					update_comment_meta( $post_id, "_user_comment_IP_rating_plus", $post_users_plus );
					$response['post_meta_plus_new_IP_comment'] = get_post_meta( $post_id, "_user_comment_IP_rating_plus" );

					// after update update
					if ( $post_users_minus ) {
						update_comment_meta( $post_id, "_user_comment_IP_rating_minus", $post_users_minus );
					}
				} else { 

					// after delete update
					update_post_meta( $post_id, "_user_IP_rating_plus", $post_users_plus );
					$response['post_meta_plus_new_IP'] = get_post_meta( $post_id, "_user_IP_rating_plus" );

					// after update update
					if ( $post_users_minus ) {
						update_post_meta( $post_id, "_user_IP_rating_minus", $post_users_minus );
					}
				}
			}

			$response['count_plus_double'] = $count_plus_double;
			if($count_plus_double == true){
				$rating_count = --$count;
				$rating_count = --$count;
			} else if($count_plus_double == false){
				$rating_count = --$count;
			}

			
			$response['status'] = "rating_minus";
			$response['icon'] = get_rating_minus_icon();

			if ( $is_comment == 1 ) {
				update_comment_meta( $post_id, "_comment_rating_count", $rating_count );
				update_comment_meta( $post_id, "_comment_rating_modified", date( 'Y-m-d H:i:s' ) );
			} else { 
				update_post_meta( $post_id, "_post_rating_count", $rating_count );
				update_post_meta( $post_id, "_post_rating_modified", date( 'Y-m-d H:i:s' ) );
			}
			$response['count'] = get_rating_count( $rating_count );
			$response['testing'] = $is_comment;

		} 

		

		if ( $disabled == true ) {
			if ( $is_comment == 1 ) {
				wp_redirect( get_permalink( get_the_ID() ) );
				exit();
			} else {
				wp_redirect( get_permalink( $post_id ) );
				exit();
			}
		} else {
			wp_send_json( $response );
		}
	}
}



/**
 * Processes like/unlike
 * @since    0.5
 */
add_action( 'wp_ajax_nopriv_process_simple_like', 'process_simple_like' );
add_action( 'wp_ajax_process_simple_like', 'process_simple_like' );
function process_simple_like() {
	// Security
	$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : 0;
	if ( !wp_verify_nonce( $nonce, 'simple-likes-nonce' ) ) {
		exit( __( 'Not permitted', 'themes-monsters' ) );
	}
	// Test if javascript is disabled
	$disabled = ( isset( $_REQUEST['disabled'] ) && $_REQUEST['disabled'] == true ) ? true : false;
	// Test if this is a comment
	$is_comment = ( isset( $_REQUEST['is_comment'] ) && $_REQUEST['is_comment'] == 1 ) ? 1 : 0;
	// Base variables
	$post_id = ( isset( $_REQUEST['post_id'] ) && is_numeric( $_REQUEST['post_id'] ) ) ? $_REQUEST['post_id'] : '';
	$result = array();
	$post_users = NULL;
	$like_count = 0;
	// Get plugin options
	if ( $post_id != '' ) {
		$count = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_comment_like_count", true ) : get_post_meta( $post_id, "_post_like_count", true ); // like count
		$count = ( isset( $count ) && is_numeric( $count ) ) ? $count : 0;
		if ( !already_liked( $post_id, $is_comment ) ) { // Like the post
			if ( is_user_logged_in() ) { // user is logged in
				$user_id = get_current_user_id();
				$post_users = post_user_likes( $user_id, $post_id, $is_comment );
				if ( $is_comment == 1 ) {
					// Update User & Comment
					$user_like_count = get_user_option( "_comment_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					update_user_option( $user_id, "_comment_like_count", ++$user_like_count );
					if ( $post_users ) {
						update_comment_meta( $post_id, "_user_comment_liked", $post_users );
					}
				} else {
					// Update User & Post
					$user_like_count = get_user_option( "_user_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					update_user_option( $user_id, "_user_like_count", ++$user_like_count );
					if ( $post_users ) {
						update_post_meta( $post_id, "_user_liked", $post_users );
					}
				}
			} else { // user is anonymous
				$user_ip = sl_get_ip();
				$post_users = post_ip_likes( $user_ip, $post_id, $is_comment );
				// Update Post
				if ( $post_users ) {
					if ( $is_comment == 1 ) {
						update_comment_meta( $post_id, "_user_comment_IP", $post_users );
					} else { 
						update_post_meta( $post_id, "_user_IP", $post_users );
					}
				}
			}
			$like_count = ++$count;
			$response['status'] = "liked";
			$response['icon'] = get_liked_icon();
		} else { // Unlike the post
			if ( is_user_logged_in() ) { // user is logged in
				$user_id = get_current_user_id();
				$post_users = post_user_likes( $user_id, $post_id, $is_comment );
				// Update User
				if ( $is_comment == 1 ) {
					$user_like_count = get_user_option( "_comment_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					if ( $user_like_count > 0 ) {
						update_user_option( $user_id, "_comment_like_count", --$user_like_count );
					}
				} else {
					$user_like_count = get_user_option( "_user_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					if ( $user_like_count > 0 ) {
						update_user_option( $user_id, '_user_like_count', --$user_like_count );
					}
				}
				// Update Post
				if ( $post_users ) {	
					$uid_key = array_search( $user_id, $post_users );
					unset( $post_users[$uid_key] );
					if ( $is_comment == 1 ) {
						update_comment_meta( $post_id, "_user_comment_liked", $post_users );
					} else { 
						update_post_meta( $post_id, "_user_liked", $post_users );
					}
				}
			} else { // user is anonymous
				$user_ip = sl_get_ip();
				$post_users = post_ip_likes( $user_ip, $post_id, $is_comment );
				// Update Post
				if ( $post_users ) {
					$uip_key = array_search( $user_ip, $post_users );
					unset( $post_users[$uip_key] );
					if ( $is_comment == 1 ) {
						update_comment_meta( $post_id, "_user_comment_IP", $post_users );
					} else { 
						update_post_meta( $post_id, "_user_IP", $post_users );
					}
				}
			}
			$like_count = ( $count > 0 ) ? --$count : 0; // Prevent negative number
			$response['status'] = "unliked";
			$response['icon'] = get_unliked_icon();
		}
		if ( $is_comment == 1 ) {
			update_comment_meta( $post_id, "_comment_like_count", $like_count );
			update_comment_meta( $post_id, "_comment_like_modified", date( 'Y-m-d H:i:s' ) );
		} else { 
			update_post_meta( $post_id, "_post_like_count", $like_count );
			update_post_meta( $post_id, "_post_like_modified", date( 'Y-m-d H:i:s' ) );
		}
		$response['count'] = get_like_count( $like_count );
		$response['testing'] = $is_comment;
		if ( $disabled == true ) {
			if ( $is_comment == 1 ) {
				wp_redirect( get_permalink( get_the_ID() ) );
				exit();
			} else {
				wp_redirect( get_permalink( $post_id ) );
				exit();
			}
		} else {
			wp_send_json( $response );
		}
	}
}

/**
 * Utility to test if the post is already rating is set
 * @since    0.5
 */
function already_rating_test( $post_id, $is_comment, $change, $rating_loggedin ) {
	$post_users = NULL;
	$user_id = NULL;
	$change_value = NULL;
	$rating_loggedin = filter_var($rating_loggedin, FILTER_VALIDATE_BOOLEAN);
	

	if ( is_user_logged_in() ) { // user is logged in
		$user_id = get_current_user_id();

		if($change == "plus"){
			$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_plus" ) : get_post_meta( $post_id, "_user_rating_plus" );
		} else if($change == "minus"){
			$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_minus" ) : get_post_meta( $post_id, "_user_rating_minus" );
		}

		if(isset($change_value[0]) && !empty($change_value[0])){
			$change_value = $change_value[0];
		}

	} else { // user is anonymous

		if($rating_loggedin == false){

			$user_id = sl_get_ip();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating" ) : get_post_meta( $post_id, "_user_IP_rating" ); 

			if($change == "plus"){
				$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_plus" ) : get_post_meta( $post_id, "_user_IP_rating_plus" ); 
			} else if($change == "minus"){
				$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_minus" ) : get_post_meta( $post_id, "_user_IP_rating_minus" ); 
			}

			if(isset($change_value[0]) && !empty($change_value[0])){
				$change_value = $change_value[0];
			}

		}

	}
	
	

	return $change_value;
	// if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
	if ( is_array( $change_value ) && in_array( $user_id, $change_value ) ) {
		return true;
	} else {
		if($rating_loggedin == false){ // all can
			return false;
		} else { // only logged in - true
			if(!is_user_logged_in()){
				return true;
			}
		}
	}
} // already_rating()

/**
 * Utility to test if the post is already rating is set
 * @since    0.5
 */
function already_rating( $post_id, $is_comment, $change, $rating_loggedin ) {
	$post_users = NULL;
	$user_id = NULL;
	$change_value = NULL;
	$rating_loggedin = filter_var($rating_loggedin, FILTER_VALIDATE_BOOLEAN);

	if ( is_user_logged_in() ) { // user is logged in
		$user_id = get_current_user_id();

		if($change == "plus"){
			$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_plus" ) : get_post_meta( $post_id, "_user_rating_plus" );
		} else if($change == "minus"){
			$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_minus" ) : get_post_meta( $post_id, "_user_rating_minus" );
		}

		if(isset($change_value[0]) && !empty($change_value[0])){
			$change_value = $change_value[0];
		}

	} else { // user is anonymous

		if($rating_loggedin == false){

			$user_id = sl_get_ip();

			if($change == "plus"){
				$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_plus" ) : get_post_meta( $post_id, "_user_IP_rating_plus" ); 
			} else if($change == "minus"){
				$change_value = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_minus" ) : get_post_meta( $post_id, "_user_IP_rating_minus" ); 
			}

			if(isset($change_value[0]) && !empty($change_value[0])){
				$change_value = $change_value[0];
			}

		}

	}
	// if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
	if ( is_array( $change_value ) && in_array( $user_id, $change_value ) ) {
		return true;
	} else {
		if($rating_loggedin == false){ // all can
			return false;
		} else { // only logged in - true
			if(!is_user_logged_in()){
				return true;
			}
		}
	}
} // already_rating()

/**
 * Utility to test if the post is already liked
 * @since    0.5
 */
function already_liked( $post_id, $is_comment ) {
	$post_users = NULL;
	$user_id = NULL;
	if ( is_user_logged_in() ) { // user is logged in
		$user_id = get_current_user_id();
		$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
		if ( count( $post_meta_users ) != 0 ) {
			$post_users = $post_meta_users[0];
		}
	} else { // user is anonymous
		$user_id = sl_get_ip();
		$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" ); 
		if ( count( $post_meta_users ) != 0 ) { // meta exists, set up values
			$post_users = $post_meta_users[0];
		}
	}
	if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
		return true;
	} else {
		return false;
	}
} // already_liked()

/**
 * Output the rating button
 * @since    0.5
 */
function get_simple_rating_button( $post_id, $is_comment = NULL, $rating_loggedin = false ) {
	$is_comment = ( NULL == $is_comment ) ? 0 : 1;
	$output = '';
	$rating_loggedin_class = '';
	$nonce = wp_create_nonce( 'rating-change-nonce' ); // Security

	$rating_loggedin_text = 'false';
	if($rating_loggedin == true){
		$rating_loggedin_text = 'true';
		if(!is_user_logged_in()){
			$rating_loggedin_class = " rating-only-loggedin ";
		}
	} else if($rating_loggedin == false){
		$rating_loggedin_text = 'false';
	}

	$already_plus = false;
	$already_minus = false;
	$user_ip = sl_get_ip();
	$user_id = get_current_user_id();

	if ( $is_comment == 1 ) {

		$post_id_class_plus = esc_attr( ' rating-plus-comment-button-' . $post_id );
		$comment_class_plus = esc_attr( ' rating-plus-comment' );

		$post_id_class_minus = esc_attr( ' rating-minus-comment-button-' . $post_id );
		$comment_class_minus = esc_attr( ' rating-minus-comment' );

		// if rating was before
		if(is_user_logged_in()){
			$change_value_plus = get_comment_meta( $post_id, "_user_comment_rating_plus" );
			$change_value_minus = get_comment_meta( $post_id, "_user_comment_rating_minus" );
			if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
				$change_value_plus = $change_value_plus[0];
			}
			if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
				$change_value_minus = $change_value_minus[0];
			}
			if ( in_array( $user_id, $change_value_plus ) ) {
				$already_plus = true;
			}
			if ( in_array( $user_id, $change_value_minus ) ) {
				$already_minus = true;
			}
		} else {
			$change_value_plus = get_comment_meta( $post_id, "_user_comment_IP_rating_plus" );
			$change_value_minus = get_comment_meta( $post_id, "_user_comment_IP_rating_minus" );
			if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
				$change_value_plus = $change_value_plus[0];
			}
			if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
				$change_value_minus = $change_value_minus[0];
			}
			if ( in_array( $user_ip, $change_value_plus ) ) {
				$already_plus = true;
			}
			if ( in_array( $user_ip, $change_value_minus ) ) {
				$already_minus = true;
			}
		}


		
		if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
			$change_value_minus = $change_value_minus[0];
		}
		if ( in_array( $user_id, $change_value_minus ) ) {
			$already_minus = true;
		}

		$rating_count = get_comment_meta( $post_id, "_comment_rating_count", true );
		$rating_count = ( isset( $rating_count ) && is_numeric( $rating_count ) ) ? $rating_count : 0;


	} else {
		

		$post_id_class_plus = esc_attr( ' rating-plus-button-' . $post_id );
		$comment_class_plus = esc_attr( '' );

		$post_id_class_minus = esc_attr( ' rating-minus-button-' . $post_id );
		$comment_class_minus = esc_attr( '' );

		// if rating was before 
		if(is_user_logged_in()){
			$change_value_plus = get_post_meta( $post_id, "_user_rating_plus" );
			$change_value_minus = get_post_meta( $post_id, "_user_rating_minus" );
			if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
				$change_value_plus = $change_value_plus[0];
			}
			if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
				$change_value_minus = $change_value_minus[0];
			}
			if ( in_array( $user_id, $change_value_plus ) ) {
				$already_plus = true;
			}
			if ( in_array( $user_id, $change_value_minus ) ) {
				$already_minus = true;
			}
		} else {
			$change_value_plus =  get_post_meta( $post_id, "_user_IP_rating_plus" );
			$change_value_minus = get_post_meta( $post_id, "_user_IP_rating_minus" );
			if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
				$change_value_plus = $change_value_plus[0];
			}
			if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
				$change_value_minus = $change_value_minus[0];
			}
			if ( in_array( $user_ip, $change_value_plus ) ) {
				$already_plus = true;
			}
			if ( in_array( $user_ip, $change_value_minus ) ) {
				$already_minus = true;
			}
		}
		
		
		
		

		$rating_count = get_post_meta( $post_id, "_post_rating_count", true );
		$rating_count = ( isset( $rating_count ) && is_numeric( $rating_count ) ) ? $rating_count : 0;
	}

	$already_plus_class = '';
	$already_minus_class = '';
	if($already_plus == true){
		$already_plus_class = ' rating-button-already-plus ';
	} 
	if($already_minus == true){
		$already_minus_class = ' rating-button-already-minus ';
	} 
	// var_dump($already_plus);
	// var_dump($already_minus);

	$count = get_rating_count( $rating_count );

	// Loader
	// $loader = '<span id="like-loader"></span>';
	$loader = '';
	$class = '';
	
	$output = '
		<span class="rating-wrap align-self-center '.$rating_loggedin_class.'">

			<a href="' . admin_url( 'admin-ajax.php?action=process_rating_change_minus' . '&post_id=' . $post_id . '&nonce=' . $nonce . '&is_comment=' . $is_comment . '&disabled=true' ) . '" class="rating-button-minus' . $already_minus_class . $post_id_class_minus . $class . $comment_class_minus . '" data-nonce="' . $nonce . '" data-post-id="' . $post_id . '" data-loggedin="'.$rating_loggedin_text.'" data-iscomment="' . $is_comment . '" title="' . __('Minus Rating','themes-monsters') . '">' . get_rating_minus_icon() . '
			</a>

			<span class="rating-button-count">'.$count.'</span>

			<a href="' . admin_url( 'admin-ajax.php?action=process_rating_change_plus' . '&post_id=' . $post_id . '&nonce=' . $nonce . '&is_comment=' . $is_comment . '&disabled=true' ) . '" class="rating-button-plus'. $already_plus_class . $post_id_class_plus . $class . $comment_class_plus . '" data-nonce="' . $nonce . '" data-post-id="' . $post_id . '" data-loggedin="'.$rating_loggedin_text.'" data-iscomment="' . $is_comment . '" title="' . __('Plus Rating','themes-monsters') . '">' . get_rating_plus_icon() . '
			</a>

		</span>';
	return $output;
} // get_simple_rating_button()

/**
 * Output the like button
 * @since    0.5
 */
function get_simple_likes_button( $post_id, $is_comment = NULL ) {
	$is_comment = ( NULL == $is_comment ) ? 0 : 1;
	$output = '';
	$nonce = wp_create_nonce( 'simple-likes-nonce' ); // Security
	if ( $is_comment == 1 ) {
		$post_id_class = esc_attr( ' like-comment-button-' . $post_id );
		$comment_class = esc_attr( ' like-comment' );
		$like_count = get_comment_meta( $post_id, "_comment_like_count", true );
		$like_count = ( isset( $like_count ) && is_numeric( $like_count ) ) ? $like_count : 0;
	} else {
		$post_id_class = esc_attr( ' like-button-' . $post_id );
		$comment_class = esc_attr( '' );
		$like_count = get_post_meta( $post_id, "_post_like_count", true );
		$like_count = ( isset( $like_count ) && is_numeric( $like_count ) ) ? $like_count : 0;
	}
	$count = get_like_count( $like_count );
	$icon_empty = get_unliked_icon();
	$icon_full = get_liked_icon();
	// Loader
	// $loader = '<span id="like-loader"></span>';
	$loader = '';

	// Liked/Unliked Variables
	if ( already_liked( $post_id, $is_comment ) ) {
		$class = esc_attr( ' liked' );
		$title = __( 'Unlike', 'themes-monsters' );
		$icon = $icon_full;
	} else {
		$class = '';
		$title = __( 'Like', 'themes-monsters' );
		$icon = $icon_empty;
	}
	$output = '<span class="likes-wrap align-self-center"><a href="' . admin_url( 'admin-ajax.php?action=process_simple_like' . '&post_id=' . $post_id . '&nonce=' . $nonce . '&is_comment=' . $is_comment . '&disabled=true' ) . '" class="like-button' . $post_id_class . $class . $comment_class . '" data-nonce="' . $nonce . '" data-post-id="' . $post_id . '" data-iscomment="' . $is_comment . '" title="' . $title . '">' . $icon . $count . '</a>' . $loader . '</span>';
	return $output;
} // get_simple_likes_button()

/**
 * Utility retrieves post meta user likes (user id array), 
 * then adds new user id to retrieved array
 * @since    0.5
 */
function post_user_rating_change( $user_id, $post_id, $is_comment, $change) {
	$change_value_plus = '';
	$change_value_minus = '';
	$change_users_plus = array();
	$change_users_minus = array();

	$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_plus" ) : get_post_meta( $post_id, "_user_rating_plus" );
	if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
		$change_users_plus = $change_value_plus[0];
	}

	$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_minus" ) : get_post_meta( $post_id, "_user_rating_minus" );
	if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
		$change_users_minus = $change_value_minus[0];
	}

	if($change == "plus"){

		if ( !in_array( $user_id, $change_users_plus ) ) {
			$change_users_plus['user-' . $user_id] = $user_id;
		}

		return $change_users_plus;

	} else if($change == "minus"){

		if ( !in_array( $user_id, $change_users_minus ) ) {
			$change_users_minus['user-' . $user_id] = $user_id;
		}

		return $change_users_minus;

	} else {
		return false;
	}
	
} 

/**
 * Utility retrieves post meta user likes (user id array), 
 * then adds new user id to retrieved array
 * @since    0.5
 */
function post_user_rating_change_delete( $user_id, $post_id, $is_comment, $change ) {
	$change_value_plus = '';
	$change_value_minus = '';
	$change_users_plus = array();
	$change_users_minus = array();

	$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_plus" ) : get_post_meta( $post_id, "_user_rating_plus" );
	if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
		$change_users_plus = $change_value_plus[0];
	}

	$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating_minus" ) : get_post_meta( $post_id, "_user_rating_minus" );
	if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
		$change_users_minus = $change_value_minus[0];
	}

	if($change == "plus"){
	
		if ( in_array( $user_id, $change_users_plus ) ) {
			unset($change_users_plus['user-' . $user_id]);
		}
		

		return $change_users_plus;

	} else if($change == "minus"){

		if ( in_array( $user_id, $change_users_minus ) ) {
			unset($change_users_minus['user-' . $user_id]);
		}

		return $change_users_minus;

	} else {
		return false;
	}
	
} 

/**
 * Utility retrieves post meta user likes (user id array), 
 * then adds new user id to retrieved array
 * @since    0.5
 */
function post_user_rating( $user_id, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_rating" ) : get_post_meta( $post_id, "_user_rating" );


	if ( isset($post_meta_users[0]) && !empty($post_meta_users[0]) ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

/**
 * Utility retrieves post meta user likes (user id array), 
 * then adds new user id to retrieved array
 * @since    0.5
 */
function post_user_likes( $user_id, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

/**
 * Utility retrieves post meta ip likes (ip array), 
 * then adds new ip to retrieved array
 * @since    0.5
 */
function post_ip_rating_change( $user_ip, $post_id, $is_comment, $change ) {
	
	$change_value_plus = '';
	$change_value_minus = '';
	$change_users_plus = array();
	$change_users_minus = array();

	$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_plus" ) : get_post_meta( $post_id, "_user_IP_rating_plus" );
	if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
		$change_users_plus = $change_value_plus[0];
	}

	$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_minus" ) : get_post_meta( $post_id, "_user_IP_rating_minus" );
	if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
		$change_users_minus = $change_value_minus[0];
	}

	if($change == "plus"){

		if ( !in_array( $user_ip, $change_users_plus ) ) {
			$change_users_plus['ip-' . $user_ip] = $user_ip;
		}

		return $change_users_plus;

	} else if($change == "minus"){

		if ( !in_array( $user_ip, $change_users_minus ) ) {
			$change_users_minus['ip-' . $user_ip] = $user_ip;
		}

		return $change_users_minus;

	} else {
		return false;
	}

} // post_ip_rating_change()

/**
 * Utility retrieves post meta ip likes (ip array), 
 * then adds new ip to retrieved array
 * @since    0.5
 */
function post_ip_rating_change_delete( $user_ip, $post_id, $is_comment, $change ) {
	
	$change_value_plus = '';
	$change_value_minus = '';
	$change_users_plus = array();
	$change_users_minus = array();

	$change_value_plus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_plus" ) : get_post_meta( $post_id, "_user_IP_rating_plus" );
	if ( isset($change_value_plus[0]) && !empty($change_value_plus[0]) ) {
		$change_users_plus = $change_value_plus[0];
	}

	$change_value_minus = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP_rating_minus" ) : get_post_meta( $post_id, "_user_IP_rating_minus" );
	if ( isset($change_value_minus[0]) && !empty($change_value_minus[0]) ) {
		$change_users_minus = $change_value_minus[0];
	}

	if($change == "plus"){

		if ( in_array( $user_ip, $change_users_plus ) ) {
			unset($change_users_plus['ip-' . $user_ip]);
		}

		return $change_users_plus;

	} else if($change == "minus"){

		if ( in_array( $user_ip, $change_users_minus ) ) {
			unset($change_users_minus['ip-' . $user_ip]);
		}

		return $change_users_minus;

	} else {
		return false;
	}

} // post_ip_rating_change()

/**
 * Utility retrieves post meta ip likes (ip array), 
 * then adds new ip to retrieved array
 * @since    0.5
 */
function post_ip_likes( $user_ip, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" );
	// Retrieve post information
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_ip, $post_users ) ) {
		$post_users['ip-' . $user_ip] = $user_ip;
	}
	return $post_users;
} // post_ip_likes()

/**
 * Utility to retrieve IP address
 * @since    0.5
 */
function sl_get_ip() {
	if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
	}
	$ip = filter_var( $ip, FILTER_VALIDATE_IP );
	$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
	return $ip;
} // sl_get_ip()

/**
 * Utility returns the button icon for Rating Plus action
 * @since    0.5
 */
function get_rating_plus_icon() {
	$icon = '<div class="rating-icon rating-icon-up"></div>';
	return $icon;
} // get_rating_plus_icon()

/**
 * Utility returns the button icon for Rating Minus action
 * @since    0.5
 */
function get_rating_minus_icon() {
	$icon = '<div class="rating-icon rating-icon-down"></div>';
	return $icon;
} // get_rating_minus_icon()


/**
 * Utility returns the button icon for "like" action
 * @since    0.5
 */
function get_liked_icon() {
	/* If already using Font Awesome with your theme, replace svg with: <i class="fa fa-heart"></i> */
	$icon = '<span class="likes-icon icon-heart"></span>';
	return $icon;
} // get_liked_icon()

/**
 * Utility returns the button icon for "unlike" action
 * @since    0.5
 */
function get_unliked_icon() {
	/* If already using Font Awesome with your theme, replace svg with: <i class="fa fa-heart-o"></i> */
	$icon = '<span class="likes-icon icon-heart icon-heart-unliked"></span>';
	return $icon;
} // get_unliked_icon()

/**
 * Utility function to format the button count,
 * appending "K" if one thousand or greater,
 * "M" if one million or greater,
 * and "B" if one billion or greater (unlikely).
 * $precision = how many decimal points to display (1.25K)
 * @since    0.5
 */
function sl_format_count( $number ) {
	$precision = 2;
	if ( $number >= 1000 && $number < 1000000 ) {
		$formatted = number_format( $number/1000, $precision ).'K';
	} else if ( $number >= 1000000 && $number < 1000000000 ) {
		$formatted = number_format( $number/1000000, $precision ).'M';
	} else if ( $number >= 1000000000 ) {
		$formatted = number_format( $number/1000000000, $precision ).'B';
	} else {
		$formatted = $number; // Number is less than 1000
	}
	$formatted = str_replace( '.00', '', $formatted );
	return $formatted;
} // sl_format_count()


/**
 * Utility retrieves count plus count options, 
 * returns appropriate format based on options
 * @since    0.5
 */
function get_rating_count( $rating_count ) {
	$rating_text = __( 'Rating', 'themes-monsters' );
	if ( is_numeric( $rating_count ) ) { 
		$number = sl_format_count( $rating_count );
	} else {
		$number = $rating_text;
	}
	$count = '<span class="rating-label">' . $number . '</span>';
	return $count;
} // get_rating_count()

/**
 * Utility retrieves count plus count options, 
 * returns appropriate format based on options
 * @since    0.5
 */
function get_like_count( $like_count ) {
	$like_text = __( 'Like', 'themes-monsters' );
	if ( is_numeric( $like_count ) && $like_count > 0 ) { 
		$number = sl_format_count( $like_count );
	} else {
		$number = $like_text;
	}
	$count = '<span class="likes-label">' . $number . '</span>';
	return $count;
} // get_like_count()

// User Profile List
add_action( 'show_user_profile', 'show_user_likes' );
add_action( 'edit_user_profile', 'show_user_likes' );
function show_user_likes( $user ) { ?>        
	<table class="form-table">
		<tr>
			<th><label for="user_likes"><?php _e( 'You Like:', 'themes-monsters' ); ?></label></th>
			<td>
			<?php
			$types = get_post_types( array( 'public' => true ) );
			$args = array(
			  'numberposts' => -1,
			  'post_type' => $types,
			  'meta_query' => array (
				array (
				  'key' => '_user_liked',
				  'value' => $user->ID,
				  'compare' => 'LIKE'
				)
			  ) );		
			$sep = '';
			$like_query = new WP_Query( $args );
			if ( $like_query->have_posts() ) : ?>
			<p>
			<?php while ( $like_query->have_posts() ) : $like_query->the_post(); 
			echo $sep; ?><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
			<?php
			$sep = ' &middot; ';
			endwhile; 
			?>
			</p>
			<?php else : ?>
			<p><?php _e( 'You do not like anything yet.', 'themes-monsters' ); ?></p>
			<?php 
			endif; 
			wp_reset_postdata(); 
			?>
			</td>
		</tr>
	</table>
<?php } // show_user_likes()


// User Profile List
add_action( 'show_user_profile', 'show_user_ratings' );
add_action( 'edit_user_profile', 'show_user_ratings' );
function show_user_ratings( $user ) { ?>        
	<table class="form-table">
		<tr>
			<th>
				<label for="user_ratings_plus"><?php _e( 'You rated as "Plus":', 'themes-monsters' ); ?></label>
			</th>

			<td>
				<?php
				$types = get_post_types( array( 'public' => true ) );
				$args_plus = array(
				  'numberposts' => -1,
				  'post_type' => $types,
				  'meta_query' => array (
					array (
					  'key' => '_user_rating_plus',
					  'value' => $user->ID,
					  'compare' => 'LIKE'
					)
				  ) );		
				$sep = '';
				$rating_plus_query = new WP_Query( $args_plus );
				if ( $rating_plus_query->have_posts() ) : ?>
					<p>
					<?php while ( $rating_plus_query->have_posts() ) : $rating_plus_query->the_post(); ?>
						<?php echo $sep; ?>
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php the_title(); ?>
						</a>
						<?php $sep = ' &middot; '; ?>
					<?php endwhile; ?>
					</p>
				<?php else : ?>
					<p><?php _e( 'You do not rated anything yet.', 'themes-monsters' ); ?></p>
					<?php 
				endif; 

				wp_reset_postdata(); 

				?>
			</td>
		</tr>
		<tr>
			<th>
				<label for="user_ratings_minus"><?php _e( 'You rated as "Minus":', 'themes-monsters' ); ?></label>
			</th>

			<td>
				<?php
				$types = get_post_types( array( 'public' => true ) );
				$args_minus = array(
				  'numberposts' => -1,
				  'post_type' => $types,
				  'meta_query' => array (
					array (
					  'key' => '_user_rating_minus',
					  'value' => $user->ID,
					  'compare' => 'LIKE'
					)
				  ) );		
				$sep = '';
				$rating_minus_query = new WP_Query( $args_minus );
				if ( $rating_minus_query->have_posts() ) : ?>
					<p>
					<?php while ( $rating_minus_query->have_posts() ) : $rating_minus_query->the_post(); ?>
						<?php echo $sep; ?>
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php the_title(); ?>
						</a>
						<?php $sep = ' &middot; '; ?>
					<?php endwhile; ?>
					</p>
				<?php else : ?>
					<p><?php _e( 'You do not rated anything yet.', 'themes-monsters' ); ?></p>
					<?php 
				endif; 

				wp_reset_postdata(); 

				?>
			</td>
		</tr>

		<tr>
			<th>
				<label for="user_ratings_count"><?php _e( 'You Ratings that was count for all "Plus" actions:', 'themes-monsters' ); ?></label>
			</th>

			<td>
				<?php echo get_user_option('_user_rating_count', get_current_user_id()); ?>
			</td>
		</tr>

	</table>
<?php } // show_user_ratings()
