<?php
// Gallery List Widget
class ThemesMonsters_Widget_Category_List extends WP_Widget {

	/**
	 * Sets up a new Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'themesmonsters_category_list_widget',
			'description'                 => __( 'Your site&#8217;s Category List.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'ThemesMonsters_Widget_Category_List', __( 'ThemesMonsters Category List' ), $widget_ops );
		$this->alt_option_name = 'themesmonsters_category_list_widget';

		$this->defaults[ 'plugin_slug' ] = 'themesmonsters_category_list_widget';
	}

	public function icon_type($cat_radio_icon, $cat_icon_img, $cat_icon){

		if(isset($cat_radio_icon) && !empty($cat_radio_icon)){
			if($cat_radio_icon == 'img'){
				if(isset($cat_icon_img) && !empty($cat_icon_img)){ ?> 
    				<div class="themesmonsters-icon-img" style="background-image: url('<?php echo esc_url($cat_icon_img); ?>');"></div>
    			<?php }
			} else {
				if(isset($cat_icon) && !empty($cat_icon)){ ?> 
    				<i class="themesmonsters-icon <?php echo $cat_icon; ?>"></i>
    			<?php } 
			}
		} else {
			if(isset($cat_icon) && !empty($cat_icon)){ ?> 
				<i class="themesmonsters-icon <?php echo $cat_icon; ?>"></i>
			<?php } 
		}
	}

	/**
	 * Outputs the content for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */

	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}


		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$show_cats = isset( $instance['cats'] ) ? $instance['cats'] : "";

		/**
		 * Filters the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 * @since 4.9.0 Added the `$instance` parameter.
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args     An array of arguments used to retrieve the recent posts.
		 * @param array $instance Array of settings for the current widget.
		 */
		$no_cats = 0;

		if(isset($show_cats) && !empty($show_cats)){
			$cats = get_categories( array(
				'taxonomy'     => 'category',
				'type'         => 'post',
				'orderby'      => 'count',
				'order'        => 'DESC',
				'hide_empty'   => 0,
				'exclude'      => '',
				'include'      => $show_cats,
				'pad_counts'   => false,
			) );
		} else {
			$cats = get_categories( array(
				'taxonomy'     => 'category',
				'type'         => 'post',
				'orderby'      => 'count',
				'order'        => 'DESC',
				'hide_empty'   => 0,
				'exclude'      => '',
				'include'      => '',
				'number' 	   => 5,
				'pad_counts'   => false,
			) );
		}
		if ( ! $cats ) {
			$no_cats++;
		} 

		?>


		<?php echo $args['before_widget']; ?>

		<?php 
		if(function_exists('gutenblog_get_option')){
			$gutenblog_example_content = gutenblog_get_option('gutenblog_example_content'); 
		} else{
			$gutenblog_example_content = false;
		}	
		?>

		<?php
		?>
		<!-- themesmonsters-recent-posts-wrap -->
		<div class="themesmonsters-category-list-wrap">
			<?php
			if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}
			?>

			<div class="themesmonsters-category-list-ul">

				<div id="recent-<?php echo $args['widget_id']; ?>" class="themesmonsters-category-list-ul-wrap">
					<?php if($cats){ ?>
						<ul class="themesmonsters-category-list-ul-inner">
							<?php foreach ( $cats as $cat ) : ?>
								<?php

								

								$cat_title = $cat->name;
								$cat_ID = $cat->cat_ID;
								$cat_desc = $cat->category_description;
								$cat_meta = get_term_meta($cat_ID);
        						$cat_img = '';
        						$cat_radio_icon = '';
        						$cat_icon_img = '';
        						$cat_icon = '';
        						$cat_color = '';
        						$cat_text_color = '';
        						if(isset($cat_meta['_catimg']) && !empty($cat_meta['_catimg'])){
        							$cat_img = $cat_meta['_catimg'][0];
        						}

        						if(isset($cat_meta['_catradioicon']) && !empty($cat_meta['_catradioicon'])){
        							$cat_radio_icon = $cat_meta['_catradioicon'][0];
        						}
        						if(isset($cat_meta['_caticonimg']) && !empty($cat_meta['_caticonimg'])){
        							$cat_icon_img = $cat_meta['_caticonimg'][0];
        						}
        						if(isset($cat_meta['_caticon']) && !empty($cat_meta['_caticon'])){
        							$cat_icon = $cat_meta['_caticon'][0];
        						}

        						if(isset($cat_meta['_catcolor']) && !empty($cat_meta['_catcolor'])){
        							$cat_color = $cat_meta['_catcolor'][0];
        						}
        						if(isset($cat_meta['_cattextcolor']) && !empty($cat_meta['_cattextcolor'])){
        							$cat_text_color = $cat_meta['_cattextcolor'][0];
        						}
        						$cat_count = $cat->count;
								$title      = ( ! empty( $cat_title ) ) ? $cat_title : __( '(no title)' );

								

								?>
								<li class="themesmonsters-category-list-li" style="background-color: <?php if(isset($cat_color) && !empty($cat_color)) { echo $cat_color; }?>;">

									<?php if(isset($cat_img) && !empty($cat_img)) { ?>
				                        <a href="<?php echo get_category_link($cat_ID); ?>">
				                        	<div class="themesmonsters-widget-thumb" style="background-image: url('<?php echo esc_url($cat_img); ?>')">
						                        <!-- <img src="<?php echo esc_url($cat_img); ?>" alt="<?php echo $cat->name; ?>" class="" /> -->
					                        
						                        <div class="themesmonsters-widget-content" style="color: <?php if(isset($cat_text_color) && !empty($cat_text_color)) { echo $cat_text_color; }?>;">
					                        		<div class="themesmonsters-category-list-title align-self-center">
					                        			<div class="themesmonsters-icon-wrap-left align-self-center">
															<?php $this->icon_type($cat_radio_icon, $cat_icon_img, $cat_icon); ?>
				                        			</div>
				                        			<div class="themesmonsters-icon-wrap-right align-self-center">
							                    		<div class="themesmonsters-title-wrap">
								                    		
								                    		<h6 class="entry-title themesmonsters-title-cat"><?php echo $title; ?></h6>
								                    	</div>

							                    		<?php if(isset($cat_desc) && !empty($cat_desc)){ ?>
						                        			<div class="themesmonsters-cat-desc">
						                        				<?php echo $cat_desc; ?>
						                        			</div>
						                        		<?php } ?>
				                        			</div>

					                        		</div>
					                        		<div class="themesmonsters-category-list-count align-self-center">
					                        			<?php echo $cat_count; ?>
					                        		</div>
												</div>
											</div>
											<div class="themesmonsters-category-list-overlay" style="background: linear-gradient(45deg, <?php if(isset($cat_color) && !empty($cat_color)) { echo $cat_color; }?> 60%,rgba(0,0,0,0) 100%);">
											</div>
				                        </a>
				                    <?php } else { ?>
				                    	<a href="<?php echo get_category_link($cat_ID); ?>">
				                    		<div class="themesmonsters-widget-content" style="color: <?php if(isset($cat_text_color) && !empty($cat_text_color)) { echo $cat_text_color; }?>;">
						                    	<div class="themesmonsters-category-list-title">
													<div class="themesmonsters-icon-wrap-left align-self-center">
															<?php $this->icon_type($cat_radio_icon, $cat_icon_img, $cat_icon); ?>
				                        			</div>
				                        			<div class="themesmonsters-icon-wrap-right align-self-center">
							                    		<div class="themesmonsters-title-wrap">
								                    		
								                    		<h6 class="entry-title themesmonsters-title-cat"><?php echo $title; ?></h6>
								                    	</div>

							                    		<?php if(isset($cat_desc) && !empty($cat_desc)){ ?>
						                        			<div class="themesmonsters-cat-desc">
						                        				<?php echo $cat_desc; ?>
						                        			</div>
						                        		<?php } ?>
				                        			</div>
						                    	</div>
						                    	<div class="themesmonsters-category-list-count">
				                        			<?php echo $cat_count; ?>
				                        		</div>
				                        	</div>
										</a>
				                    <?php } ?>

								</li>
							<?php endforeach; ?>
						</ul>
					<?php } else { ?>
						<h6 class="entry-title themesmonsters-title-cat"><?php _e('Not found', 'themesmonsters') ?></h6>
					<?php } ?>
				</div>
				
			</div>
			<!-- /themesmonsters-gallery-list-ul -->
		</div>
		<!-- /themesmonsters-gallery-list-wrap -->

		<?php
		echo $args['after_widget'];
	}

	public function themesmonsters_featured_categories($col = "3"){
		$no_cats = 0;

		$cats_select = 1;
		if(function_exists('gutenblog_get_option')){
			$cats_select = gutenblog_get_option('gutenblog_section_featured_categories_select');
		}

		$cats = get_categories( array(
			'taxonomy'     => 'category',
			'type'         => 'post',
			'orderby'      => 'include',
			'order'        => 'ASC',
			'hide_empty'   => 0,
			'exclude'      => '',
			'include'      => $cats_select,
			'pad_counts'   => false,
		) );
		
		if ( ! $cats ) {
			$no_cats = 1;
		} 

		?>

		<?php 
		$gutenblog_section_featured_categories_heading = "";
		if(function_exists('gutenblog_get_option')){
		    $gutenblog_section_featured_categories_heading = gutenblog_get_option('gutenblog_section_featured_categories_heading');
		}

	    $col_rows = "3";
	    
	    if($col == '1'){
	        $col_rows = "12";
	    } else if($col == '2'){
	        $col_rows = "6";
	    } else if($col == '3'){
	        $col_rows = "4";
	    } else if($col == '4'){
	        $col_rows = "3";
	    } else if($col == '6'){
	        $col_rows = "2";
	    }   
	    
	    ?>
	    <!-- Frontpage Featured Categories -->
	    <div class="frontpage-featured-categories">
	    <div class="main-wrapper">
	        <?php if(!empty($gutenblog_section_featured_categories_heading)){ ?>
	            <h5 class="block-title">
	                <span><?php echo esc_html($gutenblog_section_featured_categories_heading); ?></span>
	            </h5>
	        <?php } ?>

    		<?php if($cats){ ?>

				<div class="frontpage-featured-categories-row row">

					<?php foreach ( $cats as $cat ) : ?>
						<?php

						$cat_title = $cat->name;
						$cat_ID = $cat->cat_ID;
						$cat_desc = $cat->category_description;
						$cat_meta = get_term_meta($cat_ID);
						$cat_img = '';
						$cat_radio_icon = '';
						$cat_icon_img = '';
						$cat_icon = '';
						$cat_color = '';
						$cat_text_color = '';
						if(isset($cat_meta['_catimg']) && !empty($cat_meta['_catimg'])){
							$cat_img = $cat_meta['_catimg'][0];
						}

						if(isset($cat_meta['_catradioicon']) && !empty($cat_meta['_catradioicon'])){
							$cat_radio_icon = $cat_meta['_catradioicon'][0];
						}
						if(isset($cat_meta['_caticonimg']) && !empty($cat_meta['_caticonimg'])){
							$cat_icon_img = $cat_meta['_caticonimg'][0];
						}
						if(isset($cat_meta['_caticon']) && !empty($cat_meta['_caticon'])){
							$cat_icon = $cat_meta['_caticon'][0];
						}

						if(isset($cat_meta['_catcolor']) && !empty($cat_meta['_catcolor'])){
							$cat_color = $cat_meta['_catcolor'][0];
						}
						if(isset($cat_meta['_cattextcolor']) && !empty($cat_meta['_cattextcolor'])){
							$cat_text_color = $cat_meta['_cattextcolor'][0];
						}
						$cat_count = $cat->count;
						$title      = ( ! empty( $cat_title ) ) ? $cat_title : __( '(no title)' );
						
						?>

						<div class="col-md-<?php echo $col_rows; ?> frontpage-featured-categories-col">
							<div class="frontpage-featured-categories-item-bg" style="background-color: <?php if(isset($cat_color) && !empty($cat_color)) { echo $cat_color; }?>;">
							<?php if(isset($cat_img) && !empty($cat_img)) { ?>

		                        <a href="<?php echo get_category_link($cat_ID); ?>">

		                        	<div class="themesmonsters-widget-thumb" style="background-image: url('<?php echo esc_url($cat_img); ?>')">

				                        <!-- <img src="<?php echo esc_url($cat_img); ?>" alt="<?php echo $cat->name; ?>" class="" /> -->
			                        
				                        
									</div>
<div class="themesmonsters-widget-content" style="color: <?php if(isset($cat_text_color) && !empty($cat_text_color)) { echo $cat_text_color; }?>;">
			                        		<div class="themesmonsters-category-list-title align-self-center">
			                        			<div class="themesmonsters-icon-wrap-left align-self-center">
													<?php $this->icon_type($cat_radio_icon, $cat_icon_img, $cat_icon); ?>
		                        			</div>
		                        			<div class="themesmonsters-icon-wrap-right align-self-center">
					                    		<div class="themesmonsters-title-wrap">
						                    		
						                    		<h6 class="entry-title themesmonsters-title-cat" style="color: <?php if(isset($cat_text_color) && !empty($cat_text_color)) { echo $cat_text_color; }?>;"><?php echo $title; ?></h6>
						                    	</div>

					                    		<?php if(isset($cat_desc) && !empty($cat_desc)){ ?>
				                        			<div class="themesmonsters-cat-desc">
				                        				<?php echo $cat_desc; ?>
				                        			</div>
				                        		<?php } ?>
		                        			</div>

			                        		</div>
			                        		<div class="themesmonsters-category-list-count align-self-center">
			                        			<?php echo $cat_count; ?>
			                        		</div>
										</div>
									<div class="themesmonsters-category-list-overlay" style="background: linear-gradient(45deg, <?php if(isset($cat_color) && !empty($cat_color)) { echo $cat_color; }?> 60%,rgba(0,0,0,0) 100%);">
									</div>

		                        </a>
		                    <?php } else { ?>
		                    	<a href="<?php echo get_category_link($cat_ID); ?>">
		                    		<div class="themesmonsters-widget-content" style="color: <?php if(isset($cat_text_color) && !empty($cat_text_color)) { echo $cat_text_color; }?>;">
				                    	<div class="themesmonsters-category-list-title">
											<div class="themesmonsters-icon-wrap-left align-self-center">
													<?php $this->icon_type($cat_radio_icon, $cat_icon_img, $cat_icon); ?>
		                        			</div>
		                        			<div class="themesmonsters-icon-wrap-right align-self-center">
					                    		<div class="themesmonsters-title-wrap">
						                    		
						                    		<h6 class="entry-title themesmonsters-title-cat"><?php echo $title; ?></h6>
						                    	</div>

					                    		<?php if(isset($cat_desc) && !empty($cat_desc)){ ?>
				                        			<div class="themesmonsters-cat-desc">
				                        				<?php echo $cat_desc; ?>
				                        			</div>
				                        		<?php } ?>
		                        			</div>
				                    	</div>
				                    	<div class="themesmonsters-category-list-count">
		                        			<?php echo $cat_count; ?>
		                        		</div>
		                        	</div>
								</a>
		                    <?php } ?>

						</div>
						</div>
					<?php endforeach; ?>
				</div>

			<?php } else { ?>

				<h5 class="block-title">
	                <span><?php _e('No Featured Categories', 'themesmonsters'); ?></span>
	            </h5>

			<?php } ?>
			</div>
		</div>
		<!-- /Frontpage Featured Categories -->

		
				

		<?php 
	}

	/**
	 * Handles updating the settings for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance              = $old_instance;
		$instance['title']     = sanitize_text_field( $new_instance['title'] );

		// $instance['cats'] 	   = isset( $new_instance['cats'] ) ? esc_sql( $new_instance['cats'] ) : '';

		$instance['cats'] = esc_sql( $new_instance['cats'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Recent Posts widget.
	 *
	 * @since 2.8.0
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$color     = isset( $instance['color'] ) ? esc_attr( $instance['color'] ) : '';

		if( isset($instance['cats']) && !empty($instance['cats']) ) 
            $cats = $instance['cats'];
        else
            $cats = array();

		$all_cats = get_categories( array(
			'taxonomy'     => 'category',
			'type'         => 'post',
			'orderby'      => 'count',
			'order'        => 'DESC',
			'hide_empty'   => 0,
			'exclude'      => '',
			'include'      => '',
			'pad_counts'   => false,
		) );
		// var_dump($cats);
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'cats' ); ?>"><?php _e( 'Select Categories to show:' ); ?></label>
			<div class="">
				

				<?php if( $all_cats ){
		            printf(
		                '<select multiple="multiple" name="%s[]" id="%s" class="themesmonsters-select" style="%s">',
		                $this->get_field_name('cats'),
		                $this->get_field_id('cats'),
		                "width: 100%;"
		            );
		            foreach( $all_cats as $cat )
		            {
		                printf(
		                    '<option value="%s" class="" %s style="">%s</option>',
		                    $cat->cat_ID,
		                    in_array( $cat->cat_ID, $cats) ? 'selected="selected"' : '',
		                    $cat->name
		                );
		            }
		            echo '</select>';
		        }
		        else
		            echo 'No categories found';
		        ?>
			</div>
		</p>

		<?php
	}
}

/**
 * Register widget on init
 */
function register_themestonsters_widget_category_list () {
	register_widget( 'ThemesMonsters_Widget_Category_List' );
}
add_action( 'widgets_init', 'register_themestonsters_widget_category_list' );


// Category Image and Color
add_action ( 'edit_category_form_fields', function( $tag ){
    $cat_img = get_term_meta( $tag->term_id, '_catimg', true ); 

    $cat_radio_icon = get_term_meta( $tag->term_id, '_catradioicon', true );
    $cat_icon = get_term_meta( $tag->term_id, '_caticon', true ); 
    $cat_icon_img = get_term_meta( $tag->term_id, '_caticonimg', true ); 

    $cat_color = get_term_meta( $tag->term_id, '_catcolor', true ); 
    $cat_text_color  = get_term_meta( $tag->term_id, '_cattextcolor', true ); 
    ?>
    <style type="text/css">
    	.cat-img-wrap-inner img{
    		max-width: 150px;
    		max-height: 150px;
    	}
    	.cat-img-wrap-inner{
    		margin-bottom: 5px;
    	}
    	.cat-img-wrap{
    		padding-bottom: 10px;
    		margin-bottom: 10px;
    		border-bottom: 1px solid gray;
    		display: inline-block;
    	}

    	.cat-icon-img-wrap-inner img{
    		max-width: 150px;
    		max-height: 150px;
    	}
    	.cat-icon-img-wrap-inner{
    		margin-bottom: 5px;
    	}
    	.cat-icon-img-wrap{
    		padding-bottom: 10px;
    		margin-bottom: 10px;
    		border-bottom: 1px solid gray;
    		display: inline-block;
    	}
    </style>

    <tr class='form-field'>
        <th scope='row'>
            <label for='cat_img'><?php _e('Category Image', 'gutenblog-theme'); ?></label>
        </th>
        <td>
            <input id="cat_img" type="hidden" size="36" name="cat_img" value="<?php echo $cat_img ?>" />
            <?php if(isset($cat_img) && !empty($cat_img) ){ ?>
                <div class="cat-img-wrap">
                	<div class="cat-img-wrap-inner">
                    	<img src="<?php echo $cat_img; ?>">
                	</div>

	                <div class="cat-img-remove-wrap">
	                	<button id="cat-img-remove" role="button" class="button cat-img-remove"><?php _e('Remove Image', 'gutenblog-theme'); ?></button>
	                </div>

                </div>
            <?php } else { ?>
            	<div class="cat-img-wrap" style="display: none;">
                	<div class="cat-img-wrap-inner">

                	</div>

	                <div class="cat-img-remove-wrap">
	                	<button id="cat-img-remove" role="button" class="button cat-img-remove"><?php _e('Remove Image', 'gutenblog-theme'); ?></button>
	                </div>
	                
                </div>
            <?php } ?>

            <div class="upload-cat-img-wrap">
	            <button id="upload_cat_img" role="button" class="button upload_cat_img"><?php _e('Upload Image', 'gutenblog-theme'); ?></button>
	            <p class='description'><?php _e('Image for the Category ', 'gutenblog-theme'); ?></p>
	        </div>
            
        </td>
    </tr> 

    <!-- Radio Icon -->
    <tr class='form-field'>
        <th scope='row'>
            <label for='cat_radio_icon'><?php _e('Chose Type of Icon', 'gutenblog-theme'); ?></label>
        </th>
        <td>
        	
        	<label for="cat_radio_icon-icon"><?php _e('Icon Type', 'gutenblog-theme'); ?></label>
        	<input <?php if($cat_radio_icon != "img"){echo "checked";} ?> type="radio" id="cat_radio_icon-icon" name="cat_radio_icon" value="icon">
		    
        	<label for="cat_radio_icon-img"><?php _e('Image Type', 'gutenblog-theme'); ?></label>
		    <input <?php if($cat_radio_icon == "img"){echo "checked";} ?> type="radio" id="cat_radio_icon-img" name="cat_radio_icon" value="img">
		    
        </td>
    </tr>

    <!-- Icon IMG -->
	<tr class='form-field form-field-cat-icon-img' style="<?php if($cat_radio_icon == "img"){ echo "display: table-row"; } else { echo "display: none;"; }?>">
        <th scope='row'>
            <label for='cat_icon_img'><?php _e('Category Icon Image', 'gutenblog-theme'); ?></label>
        </th>
        <td>
            <input id="cat_icon_img" type="hidden" size="36" name="cat_icon_img" value="<?php echo $cat_icon_img ?>" />

            <?php if(isset($cat_icon_img) && !empty($cat_icon_img) ){ ?>
                <div class="cat-icon-img-wrap">
                	<div class="cat-icon-img-wrap-inner">
                    	<img src="<?php echo $cat_icon_img; ?>">
                	</div>

	                <div class="cat-icon-img-remove-wrap">
	                	<button id="cat-icon-img-remove" role="button" class="button cat-icon-img-remove"><?php _e('Remove Icon Image', 'gutenblog-theme'); ?></button>
	                </div>

                </div>
            <?php } else { ?>
            	<div class="cat-icon-img-wrap" style="display: none;">
                	<div class="cat-icon-img-wrap-inner">

                	</div>

	                <div class="cat-icon-img-remove-wrap">
	                	<button id="cat-icon-img-remove" role="button" class="button cat-icon-img-remove"><?php _e('Remove Icon Image', 'gutenblog-theme'); ?></button>
	                </div>
	                
                </div>
            <?php } ?>

            <div class="upload-cat-icon-img-wrap">
	            <button id="upload_cat_icon_img" role="button" class="button upload_cat_icon_img"><?php _e('Upload Icon Image', 'gutenblog-theme'); ?></button>
	            <p class='description'><?php _e('Icon Image for the Category ', 'gutenblog-theme'); ?></p>
	        </div>
            
        </td>
    </tr> 

    <!-- Icon -->
	<tr class='form-field form-field-cat-icon' style="<?php if($cat_radio_icon != "img"){ echo "display: table-row"; } else { echo "display: none;"; }?>">
        <th scope='row'>
            <label for='cat_icon'><?php _e('Category Icon', 'gutenblog-theme'); ?></label>
        </th>
        <td>
            <input id="cat_icon" class="" type="text" name="cat_icon" value="<?php echo $cat_icon ?>" />
            <p class='description'><?php _e('Icon for the Category ', 'gutenblog-theme'); ?></p>
        </td>
    </tr> 

    <tr class='form-field'>
        <th scope='row'>
            <label for='cat_color'><?php _e('Category Background Color', 'gutenblog-theme'); ?></label>
        </th>
        <td>
            <input id="cat_color" class="colorpicker" name="cat_color" value="<?php echo $cat_color ?>" />
            <p class='description'><?php _e('Background Color for the Category ', 'gutenblog-theme'); ?></p>
        </td>
    </tr> 

    <tr class='form-field'>
        <th scope='row'>
            <label for='cat_text_color'><?php _e('Category Text Color', 'gutenblog-theme'); ?></label>
        </th>
        <td>
            <input id="cat_text_color" class="colorpicker" name="cat_text_color" value="<?php echo $cat_text_color ?>" />
            <p class='description'><?php _e('Text Color for the Category ', 'gutenblog-theme'); ?></p>
        </td>
    </tr>
    
    <?php
});

add_action ( 'edited_category', function() {
    if ( isset( $_POST['cat_img'] ) ){
        update_term_meta( $_POST['tag_ID'], '_catimg', $_POST['cat_img'] );
    }

    if ( isset( $_POST['cat_radio_icon'] ) ){
        update_term_meta( $_POST['tag_ID'], '_catradioicon', $_POST['cat_radio_icon'] );
    }
    if ( isset( $_POST['cat_icon_img'] ) ){
        update_term_meta( $_POST['tag_ID'], '_caticonimg', $_POST['cat_icon_img'] );
    }
    if ( isset( $_POST['cat_icon'] ) ){
        update_term_meta( $_POST['tag_ID'], '_caticon', $_POST['cat_icon'] );
    }

    if ( isset( $_POST['cat_color'] ) ){
        update_term_meta( $_POST['tag_ID'], '_catcolor', $_POST['cat_color'] );
    }
    if ( isset( $_POST['cat_text_color'] ) ){
        update_term_meta( $_POST['tag_ID'], '_cattextcolor', $_POST['cat_text_color'] );
    }


});

function category_admin_scripts($hook) {
    //Load only on edit.php pages
    //You can use get_current_screen to check post type
    $screen = get_current_screen();
    if( 'term.php' != $hook || !isset($screen->id) || $screen->id != "edit-category"){
        return;
    }

    wp_enqueue_style('thickbox');

    wp_enqueue_script('jquery');
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');

    // Colorpicker Scripts
    wp_enqueue_script( 'wp-color-picker' );

    // Colorpicker Styles
    wp_enqueue_style( 'wp-color-picker' );

    // Icons
    wp_enqueue_script( 'fonticonpicker-js', plugin_dir_url( __FILE__ ).'assets/js/jquery.fonticonpicker.min.js' );
    wp_enqueue_style( 'fonticonpicker-css', plugin_dir_url( __FILE__ ).'assets/css/jquery.fonticonpicker.min.css' );
	wp_enqueue_style( 'fonticonpicker-grey-css', plugin_dir_url( __FILE__ ).'assets/css/jquery.fonticonpicker.grey.min.css' );
	wp_enqueue_style( 'fontsicomoon-css', plugin_dir_url( __FILE__ ).'assets/css/fontsicomoon.css' );
	
    // Main
    wp_enqueue_script( 'admin-scripts', plugin_dir_url( __FILE__ ).'assets/js/admin-scripts.js' );
}
add_action( 'admin_enqueue_scripts', 'category_admin_scripts' );

// function category_text_options_setup() {
//     global $pagenow;
//     if( 'term.php' != $pagenow){
//         return;
//     }
//     add_filter('gettext', 'category_replace_window_text', 1, 2);
    
// }
// add_action('admin_init', 'category_text_options_setup' );

// function category_replace_window_text($translated_text, $text) {
//     if ('Insert into Post' == $text) {
//         $referer = strpos(wp_get_referer(), 'media_page');
//         if ($referer != "") {
//             return __('Upload Image', 'gutenblog-theme');
//         }
//     }
//     return $translated_text;
// }



?>