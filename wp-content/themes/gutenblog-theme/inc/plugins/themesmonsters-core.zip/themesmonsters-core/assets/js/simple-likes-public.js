(function( $ ) {
	'use strict';
	$(document).on('click', '.like-button', function() {
		var button = $(this);
		var post_id = button.attr('data-post-id');
		var security = button.attr('data-nonce');
		var iscomment = button.attr('data-iscomment');
		var allbuttons;
		if ( iscomment === '1' ) { /* Comments can have same id */
			allbuttons = $('.like-comment-button-'+post_id);
		} else {
			allbuttons = $('.like-button-'+post_id);
		}
		var loader = allbuttons.next('#like-loader');
		if (post_id !== '') {
			$.ajax({
				type: 'POST',
				url: simpleLikes.ajaxurl,
				data : {
					action : 'process_simple_like',
					post_id : post_id,
					nonce : security,
					is_comment : iscomment,
				},
				beforeSend:function(){
					button.find('.likes-icon').addClass('like-loading');
					// loader.html('&nbsp;<div class="loader-block"></div>');
				},	
				success: function(response){
					var icon = response.icon;
					var count = response.count;
					allbuttons.html(icon+count);
					if(response.status === 'unliked') {
						var like_text = simpleLikes.like;
						allbuttons.prop('title', like_text);
						allbuttons.removeClass('liked');
					} else {
						var unlike_text = simpleLikes.unlike;
						allbuttons.prop('title', unlike_text);
						allbuttons.addClass('liked');
					}
					button.find('.likes-icon').removeClass('like-loading');
					// loader.empty();					
				}
			});
			
		}
		return false;
	});

	$(document).on('click', '.rating-wrap.rating-only-loggedin .rating-button-plus', function(e) {
		e.preventDefault();
	});
	$(document).on('click', '.rating-wrap:not(.rating-only-loggedin) .rating-button-plus', function() {
		var button = $(this);
		var wrap = $(this).closest('.rating-wrap');

		var post_id = button.attr('data-post-id');
		var security = button.attr('data-nonce');
		var iscomment = button.attr('data-iscomment');
		var loggedin = button.attr('data-loggedin');

		var allbuttons;
		if ( iscomment === '1' ) { /* Comments can have same id */
			allbuttons = wrap.find('.rating-plus-comment-button-'+post_id);
		} else {
			allbuttons = wrap.find('.rating-plus-button-'+post_id);
		}

		var allCount = wrap.find('.rating-button-count');


		var loader = wrap.find('#rating-loader');
		if (post_id !== '') {
			$.ajax({
				type: 'POST',
				url: simpleLikes.ajaxurl,
				data : {
					action : 'process_rating_change_plus',
					post_id : post_id,
					nonce : security,
					is_comment : iscomment,
					loggedin : loggedin,
				},
				beforeSend:function(){
					wrap.addClass('rating-loading');
					// loader.html('&nbsp;<div class="loader-block"></div>');
				},	
				success: function(response){
					wrap.find('.rating-button-minus').removeClass('rating-button-already-minus');
					wrap.find('.rating-button-plus').removeClass('rating-button-already-plus');

					button.addClass('rating-button-already-plus');

					// console.log(response);
					var icon = response.icon;
					var count = response.count;
					allCount.html(count);
					if(response.status === 'rating_plus') {
						var rating_text = simpleLikes.rating_plus;
						allbuttons.prop('title', rating_text);
						allbuttons.removeClass('loading');
					} 

					wrap.removeClass('rating-loading');
					// loader.empty();					
				}
			});
			
		}
		return false;
	});

	$(document).on('click', '.rating-wrap.rating-only-loggedin .rating-button-minus', function(e) {
		e.preventDefault();
	});
	$(document).on('click', '.rating-wrap:not(.rating-only-loggedin) .rating-button-minus', function() {
		var button = $(this);
		var wrap = button.closest('.rating-wrap');

		var post_id = button.attr('data-post-id');
		var security = button.attr('data-nonce');
		var iscomment = button.attr('data-iscomment');
		var loggedin = button.attr('data-loggedin');

		var allbuttons;
		if ( iscomment === '1' ) { /* Comments can have same id */
			allbuttons = wrap.find('.rating-minus-comment-button-'+post_id);
		} else {
			allbuttons = wrap.find('.rating-minus-button-'+post_id);
		}
		var allCount = wrap.find('.rating-button-count');
		var loader = wrap.find('#rating-loader');
		if (post_id !== '') {
			$.ajax({
				type: 'POST',
				url: simpleLikes.ajaxurl,
				data : {
					action : 'process_rating_change_minus',
					post_id : post_id,
					nonce : security,
					is_comment : iscomment,
					loggedin : loggedin,
				},
				beforeSend:function(){
					wrap.addClass('rating-loading');
					// loader.html('&nbsp;<div class="loader-block"></div>');
				},	
				success: function(response){
					wrap.find('.rating-button-minus').removeClass('rating-button-already-minus');
					wrap.find('.rating-button-plus').removeClass('rating-button-already-plus');

					button.addClass('rating-button-already-minus');

					// console.log(response);
					var icon = response.icon;
					var count = response.count;

					allCount.html(count);

					if(response.status === 'rating_minus') {
						var rating_text = simpleLikes.rating_minus;
						allbuttons.prop('title', rating_text);
						allbuttons.removeClass('loading');
					} 

					wrap.removeClass('rating-loading');
					// loader.empty();					
				}
			});
			
		}
		return false;
	});

})( jQuery );
