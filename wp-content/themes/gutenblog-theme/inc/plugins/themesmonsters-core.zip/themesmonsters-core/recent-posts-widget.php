<?php
// Updated Recent Posts Widget with Thumbnails
class ThemesMonsters_Widget_Recent_Posts extends WP_Widget {

	/**
	 * Sets up a new Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'widget_recent_entries_thumbs themesmonsters-recent-posts-widget',
			'description'                 => __( 'Your site&#8217;s most recent Posts with Thumbnails.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'ThemesMonsters_Widget_Recent_Posts', __( 'Recent Posts with Thumbnail' ), $widget_ops );
		$this->alt_option_name = 'widget_recent_entries_thumbs';

		$this->defaults[ 'plugin_slug' ]		= 'widget_recent_entries_thumbs';
	}

	/**
	 * Outputs the content for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}


		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number ) {
			$number = 5;
		}
		$show_thumbnail = isset( $instance['show_thumbnail'] ) ? $instance['show_thumbnail'] : false;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		$show_recent = isset( $instance['show_recent'] ) ? $instance['show_recent'] : false;
		$show_popular = isset( $instance['show_popular'] ) ? $instance['show_popular'] : false;
		$show_comments = isset( $instance['show_comments'] ) ? $instance['show_comments'] : false;

		/**
		 * Filters the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 * @since 4.9.0 Added the `$instance` parameter.
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args     An array of arguments used to retrieve the recent posts.
		 * @param array $instance Array of settings for the current widget.
		 */
		$no_posts = 0;
		$disabled_posts = 0;
		$active_toggle_recent = "";
		$active_toggle_popular = "";
		$active_toggle_comment = "";

		$active_tab_recent = "";
		$active_tab_popular = "";
		$active_tab_comment = "";

		if($show_recent == true){

			$r = new WP_Query(
				array(
					'posts_per_page'      => $number,
					'no_found_rows'       => true,
					'post_status'         => 'publish',
					'ignore_sticky_posts' => true,
					'order' 			  => 'DESC',
					'orderby' 			  => 'date'
				)
			);
			if ( ! $r->have_posts() ) {
				$no_posts++;
			} else {
				$active_toggle_recent = "active";
				$active_tab_recent = " active show";
			}
		} else {
			$disabled_posts++;
		}

		if($show_popular == true){

			$p = new WP_Query(
				array(
					'posts_per_page'      => $number,
					'no_found_rows'       => true,
					'post_status'         => 'publish',
					'ignore_sticky_posts' => true,
					'order' 			  => 'DESC',
					'orderby' 			  => 'meta_value_num',
					'meta_query'          => array(
                		'relation' => 'OR', 
	                    array(
	                        'key' => 'post_views_count',
	                        'compare' => 'NOT EXISTS',
	                    ),
	                    array(
	                        'key' => 'post_views_count',
	                        'compare' => 'EXISTS',
	                    ),
	                )
				)
			);

			if ( ! $p->have_posts() ) {
				$no_posts++;
			} else {
				if($active_toggle_recent == ""){
					$active_toggle_popular = "active";
					$active_tab_popular = " active show";
				}
			}
		} else {
			$disabled_posts++;
		}

		if($show_comments == true){
			$args_c = array(
				'status' => 'approve',
				'number' => $number,
				'order'  => 'DESC',
				'orderby' => 'date'
			);
			$c = get_comments($args_c);

			if ( count($c) != 0 && !empty($c)) {
				if($active_toggle_recent == "" && $active_toggle_popular == ""){
					$active_toggle_comment = "active";
					$active_tab_comment = "active show";
				}
			} else {
				$no_posts++;
			}
		} else {
			$disabled_posts++;
		}

		if($no_posts == 3){
			return;
		}
		if($disabled_posts == 3){
			return;
		}
		?>


		<?php echo $args['before_widget']; ?>

		<?php 
		if(function_exists('gutenblog_get_option')){
			$gutenblog_example_content = gutenblog_get_option('gutenblog_example_content'); 
		} else{
			$gutenblog_example_content = false;
		}	
		?>

		<?php
		?>
		<!-- themesmonsters-recent-posts-wrap -->
		<div class="themesmonsters-recent-posts-wrap">
			<?php
			if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}
			?>

			<?php if($no_posts == 2 || $disabled_posts == 2){ ?>

			<?php } else { ?>

				<ul class="nav nav-tabs nav-feed-sort lavalamp-wrap themesmonsters-recent-posts-ul-toggle">
					<?php if($show_recent == true){ ?>
						<li class=" themesmonsters-tab <?php echo $active_toggle_recent; ?>"><a data-toggle="tab" href="#recent-<?php echo $args['widget_id']; ?>"><?php _e('Recent','themesmonsters'); ?></a></li>
					<?php } ?>
					<?php if($show_popular == true){ ?>
						<li class=" themesmonsters-tab <?php echo $active_toggle_popular; ?>"><a data-toggle="tab" href="#popular-<?php echo $args['widget_id']; ?>"><?php _e('Popular','themesmonsters'); ?></a></li>
					<?php } ?>
					<?php if($show_comments == true){ ?>
						<li class=" themesmonsters-tab <?php echo $active_toggle_comment; ?>"><a data-toggle="tab" href="#comments-<?php echo $args['widget_id']; ?>"><?php _e('Comments','themesmonsters'); ?></a></li>
					<?php } ?>
				</ul>

			<?php } ?>

			<!-- themesmonsters-recent-posts-ul-tabs -->
			<div class="tab-content themesmonsters-recent-posts-ul-tabs">

				<?php if($show_recent == true){ ?>
					<div id="recent-<?php echo $args['widget_id']; ?>" class="themesmonsters-recent-posts-ul-wrap <?php if($disabled_posts != 2){ ?>tab-pane fade <?php echo $active_tab_recent; ?><?php } ?>">
						<?php if($r->have_posts()){ ?>
							<ul class="themesmonsters-recent-posts-ul-inner">
								<?php foreach ( $r->posts as $recent_post ) : ?>
									<?php
									$post_title = get_the_title( $recent_post->ID );
									$post_thumb = get_the_post_thumbnail_url($recent_post->ID);
									$title      = ( ! empty( $post_title ) ) ? $post_title : __( '(no title)' );

									?>
									<li class="themesmonsters-recent-posts-li">

										<?php if(has_post_thumbnail($recent_post->ID)) { ?>
					                        <a href="<?php the_permalink($recent_post->ID); ?>">
					                        	<div class="themesmonsters-widget-thumb">
						                        	<?php if($show_thumbnail){ ?>
							                        	<?php echo get_the_post_thumbnail($recent_post->ID, 'gutenblog-square', array( 'alt' => $title) ); ?>
							                        <?php } ?>
						                        </div>
						                        <div class="themesmonsters-widget-content">
					                        	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php echo $title; ?></h6></div>
					                        	<?php if ( $show_date ) { ?>
													<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
												<?php } ?>
												</div>
					                        </a>
					                    <?php } else if($gutenblog_example_content == 1) { ?>
					                        <a href="<?php the_permalink($recent_post->ID); ?>">
					                        	<div class="themesmonsters-widget-thumb">
						                        	<?php if($show_thumbnail){ ?>
						                        		<img src="<?php echo esc_url(gutenblog_thumbnails('gutenblog-square')) ?>" alt="<?php the_title_attribute($recent_post->ID) ?>" class="" />
						                        	<?php } ?>
					                        	</div>
					                        	<div class="themesmonsters-widget-content">
						                        	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php echo $title; ?></h6></div>
						                        	<?php if ( $show_date ) { ?>
														<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
													<?php } ?>
												</div>
					                        </a>
					                    <?php } else { ?>
					                    	<a href="<?php the_permalink($recent_post->ID); ?>">
						                    	<div class="themesmonsters-recent-posts-title"><?php echo $title; ?></div>
						                    	<?php if ( $show_date ) { ?>
													<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
												<?php } ?>
											</a>
					                    <?php } ?>

										

									</li>
								<?php endforeach; ?>
							</ul>
						<?php } else { ?>
							<h6 class=""><?php _e('Not found', 'themesmonsters') ?></h6>
						<?php } ?>
					</div>
				<?php } ?>

				<?php if($show_popular == true){ ?>
					<div id="popular-<?php echo $args['widget_id']; ?>" class="themesmonsters-recent-posts-ul-wrap <?php if($disabled_posts != 2){ ?>tab-pane fade <?php echo $active_tab_popular; ?><?php } ?>">
						<?php if($p->have_posts()){ ?>
							<ul class="themesmonsters-recent-posts-ul-inner">
								<?php foreach ( $p->posts as $recent_post ) : ?>
									<?php
									$post_title = get_the_title( $recent_post->ID );
									$post_thumb = get_the_post_thumbnail_url($recent_post->ID);
									$title      = ( ! empty( $post_title ) ) ? $post_title : __( '(no title)' );

									?>
									<li class="themesmonsters-recent-posts-li">

										<?php if(has_post_thumbnail($recent_post->ID)) { ?>
			                                          <a href="<?php the_permalink($recent_post->ID); ?>">
					                        	<div class="themesmonsters-widget-thumb">
						                        	<?php if($show_thumbnail){ ?>
							                        	<?php echo get_the_post_thumbnail($recent_post->ID, 'gutenblog-square', array( 'alt' => $title) ); ?>
							                        <?php } ?>
						                        </div>
						                        <div class="themesmonsters-widget-content">
					                        	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php echo $title; ?></h6></div>
					                        	<?php if ( $show_date ) { ?>
													<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
												<?php } ?>
												</div>
					                        </a>
					                    <?php } else if($gutenblog_example_content == 1) { ?>
					                        <a href="<?php the_permalink($recent_post->ID); ?>">
					      						<div class="themesmonsters-widget-thumb">
						                        	<?php if($show_thumbnail){ ?>
						                        		<img src="<?php echo esc_url(gutenblog_thumbnails('gutenblog-square')) ?>" alt="<?php the_title_attribute($recent_post->ID) ?>" class="" />
						                        	<?php } ?>
					                        	</div>
					                        	<div class="themesmonsters-widget-content">
						                        	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php echo $title; ?></h6></div>
						                        	<?php if ( $show_date ) { ?>
														<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
													<?php } ?>
												</div>
					                        </a>
					                    <?php } else { ?>
					                    	<a href="<?php the_permalink($recent_post->ID); ?>">
						                    	<div class="themesmonsters-recent-posts-title"><?php echo $title; ?></div>
						                    	<?php if ( $show_date ) { ?>
													<span class="themesmonsters-recent-posts-date"><?php echo get_the_date( '', $recent_post->ID ); ?></span>
												<?php } ?>
											</a>
					                    <?php } ?>

										

									</li>
								<?php endforeach; ?>
							</ul>
						<?php } else { ?>
							<h6 class=""><?php _e('Not found', 'themesmonsters') ?></h6>
						<?php } ?>
					</div>
				<?php } ?>

				<?php if($show_comments == true){ ?>
					<div id="comments-<?php echo $args['widget_id']; ?>" class="themesmonsters-recent-posts-ul-wrap <?php if($disabled_posts != 2){ ?>tab-pane fade <?php echo $active_tab_comment; ?><?php } ?>">
						<?php if(count($c) != 0 && !empty($c)){ ?>
							<ul class="themesmonsters-recent-posts-ul-inner">
								<?php foreach ( $c as $comment){ ?>

									<?php
									$post_title = $comment->comment_author;
									$post_content = $comment->comment_content;
									$post_thumb = "";
									$author_id = "";
									if(isset($comment->user_id) && !empty($comment->user_id)){
										$post_thumb = get_avatar_url($comment->user_id);
									} else {
										$post_thumb = get_avatar_url($comment->comment_author_email);
									} 

									$title      = ( ! empty( $post_title ) ) ? $post_title : __( '(no title)' );

									?>
									<li class="themesmonsters-recent-posts-li commments-tab">

										<?php if($post_thumb) { ?>
											<?php if($show_thumbnail){ ?>
											<div class="themesmonsters-widget-thumb">
					                        	<img src="<?php echo $post_thumb; ?>" alt="<?php echo $post_title; ?>" class="" />
					                        </div><?php } ?>
					                        <div class="themesmonsters-widget-content">
					                        	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php the_author_link(); ?></h6></div>
					                        	<div class="themesmonsters-recent-posts-content"><?php echo  $post_content; ?></div>
					                        	<?php if ( $show_date ) { ?>
													<span class="themesmonsters-recent-posts-date"><?php echo get_comment_date( '', $comment->comment_ID ); ?></span>
												<?php } ?>
					                        </div>
					                    <?php } else { ?>
					                    	<div class="themesmonsters-recent-posts-title"><h6 class="entry-title"><?php the_author_link(); ?></h6></div>
					                    	<div class="themesmonsters-recent-posts-content"><?php echo  $post_content; ?></div>
					                    	<?php if ( $show_date ) { ?>
												<span class="themesmonsters-recent-posts-date"><?php echo get_comment_date( '', $comment->comment_ID ); ?></span>
											<?php } ?>
					                    <?php } ?>

										

									</li>
								<?php } ?>
							</ul>
						<?php } else { ?>	
							<h6 class=""><?php _e('Not found', 'themesmonsters') ?></h6>
						<?php } ?>
					</div>
				<?php } ?>

			</div>
			<!-- /themesmonsters-recent-posts-ul-tabs -->
		</div>
		<!-- /themesmonsters-recent-posts-wrap -->

		<?php
		echo $args['after_widget'];
	}

	/**
	 * Handles updating the settings for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance              = $old_instance;
		$instance['title']     = sanitize_text_field( $new_instance['title'] );
		$instance['number']    = (int) $new_instance['number'];
		$instance['show_thumbnail'] = isset( $new_instance['show_thumbnail'] ) ? (bool) $new_instance['show_thumbnail'] : false;
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$instance['show_recent'] = isset( $new_instance['show_recent'] ) ? (bool) $new_instance['show_recent'] : false;
		$instance['show_popular'] = isset( $new_instance['show_popular'] ) ? (bool) $new_instance['show_popular'] : false;
		$instance['show_comments'] = isset( $new_instance['show_comments'] ) ? (bool) $new_instance['show_comments'] : false;

		return $instance;
	}

	/**
	 * Outputs the settings form for the Recent Posts widget.
	 *
	 * @since 2.8.0
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_thumbnail = isset( $instance['show_thumbnail'] ) ? (bool) $instance['show_thumbnail'] : true;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		$show_recent  = isset( $instance['show_recent'] ) ? (bool) $instance['show_recent'] : true;
		$show_popular = isset( $instance['show_popular'] ) ? (bool) $instance['show_popular'] : false;
		$show_comments = isset( $instance['show_comments'] ) ? (bool) $instance['show_comments'] : false;

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
			<input class="tiny-text" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="number" step="1" min="1" value="<?php echo $number; ?>" size="3" />
		</p>

		<p>
			<input class="checkbox" type="checkbox"<?php checked( $show_recent ); ?> id="<?php echo $this->get_field_id( 'show_recent' ); ?>" name="<?php echo $this->get_field_name( 'show_recent' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'show_recent' ); ?>"><?php _e( 'Display post "Recent Posts"?' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox"<?php checked( $show_popular ); ?> id="<?php echo $this->get_field_id( 'show_popular' ); ?>" name="<?php echo $this->get_field_name( 'show_popular' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'show_popular' ); ?>">
				<?php _e( 'Display post "Popular Posts"?' ); ?>
			</label>
		</p>
		<p>
			<input class="checkbox" type="checkbox"<?php checked( $show_comments ); ?> id="<?php echo $this->get_field_id( 'show_comments' ); ?>" name="<?php echo $this->get_field_name( 'show_comments' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'show_comments' ); ?>">
				<?php _e( 'Display post "Recent Comments"?' ); ?>
			</label>
		</p>

		<p>
			<input class="checkbox" type="checkbox"<?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'show_date' ); ?>">
				<?php _e( 'Display post date?' ); ?>
			</label>
		</p>

		<p>
			<input class="checkbox" type="checkbox"<?php checked( $show_thumbnail ); ?> id="<?php echo $this->get_field_id( 'show_thumbnail' ); ?>" name="<?php echo $this->get_field_name( 'show_thumbnail' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'show_thumbnail' ); ?>">
				<?php _e( 'Display post thumbnail?' ); ?>
			</label>
		</p>

		
		<?php
	}
}

/**
 * Register widget on init
 */
function register_themestonsters_widget_recent_posts () {
	register_widget( 'ThemesMonsters_Widget_Recent_Posts' );
}
add_action( 'widgets_init', 'register_themestonsters_widget_recent_posts' );
?>