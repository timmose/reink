<?php
/*
Plugin Name: Themes Monsters Core Plugin
Plugin URI:  
Description: Contains important functionality for correct theme work
Version: 1.1
Author: ThemesMonsters.com
Author URI: http://themesmonsters.com
License: GPL2
*/

define( 'THEMES_MONSTERS_CORE', '1.0' );
define( 'THEMES_MONSTERS_CORE_DIR', dirname( __FILE__ ) );

// Post Like System
if ( defined( 'THEMES_MONSTERS_CORE' ) 
	&& THEMES_MONSTERS_CORE 
	&& file_exists( THEMES_MONSTERS_CORE_DIR . '/post-like.php' ) 
   ) {
	require_once THEMES_MONSTERS_CORE_DIR . '/post-like.php';
}

// Post View System
if ( defined( 'THEMES_MONSTERS_CORE' ) 
	&& THEMES_MONSTERS_CORE 
	&& file_exists( THEMES_MONSTERS_CORE_DIR . '/post-view.php' ) 
   ) {
	require_once THEMES_MONSTERS_CORE_DIR . '/post-view.php';
}

// Post Share System
if ( defined( 'THEMES_MONSTERS_CORE' ) 
	&& THEMES_MONSTERS_CORE 
	&& file_exists( THEMES_MONSTERS_CORE_DIR . '/post-share.php' ) 
   ) {
	require_once THEMES_MONSTERS_CORE_DIR . '/post-share.php';
}

// Recent Posts Widget with Thumbnails
if ( defined( 'THEMES_MONSTERS_CORE' ) 
	&& THEMES_MONSTERS_CORE 
	&& file_exists( THEMES_MONSTERS_CORE_DIR . '/recent-posts-widget.php' ) 
   ) {
	require_once THEMES_MONSTERS_CORE_DIR . '/recent-posts-widget.php';
}

// Category List
if ( defined( 'THEMES_MONSTERS_CORE' ) 
	&& THEMES_MONSTERS_CORE 
	&& file_exists( THEMES_MONSTERS_CORE_DIR . '/category-list-widget.php' ) 
   ) {
	require_once THEMES_MONSTERS_CORE_DIR . '/category-list-widget.php';
}

// Custom Fonts and Styles in Gutenberg
function customizer_after_save(){ 
    if(class_exists("Kirki")){
        css_custom_fonts_editor();
    } 
}
add_action( 'customize_save_after', 'customizer_after_save' );

function css_custom_fonts_editor($test = false) {
    $style = '';
    
    if(function_exists('gutenblog_output_all_custom_fonts')){
	    $font_face = gutenblog_output_all_custom_fonts(true);// true - return and not wp_inline
	    if(isset($font_face) && !empty($font_face)){
	        $style .= $font_face;
	    }
	}

    $font_styles = gutenblog_all_font_styles();// this is only return
    if(isset($font_styles) && !empty($font_styles)){
        $style .= $font_styles;
    }
    if(isset($style) && !empty($style)){
        if(file_exists(get_template_directory() . '/assets/css/gutenblog-editor-style.css')){
            $file_content = file_get_contents(get_template_directory() . '/assets/css/gutenblog-editor-style.css');
            if($test == true){
                var_dump($style);
            }
            if($file_content != $style){
                if($test == true){

                } else {
                    file_put_contents(get_template_directory() . '/assets/css/gutenblog-editor-style.css', $style);
                }
            }
        }
    }
    
}

function gutenblog_all_font_styles(){
    $all_fields = array();
    $fields_names = array(
        'gutenblog_settings_typography_menu',
        'gutenblog_settings_typography_post_title',
        'gutenblog_settings_typography_body_font',
        'gutenblog_settings_typography_pre_code',
        'gutenblog_settings_typography_h1',
        'gutenblog_settings_typography_h2',
        'gutenblog_settings_typography_h3',
        'gutenblog_settings_typography_h4',
        'gutenblog_settings_typography_h5',
        'gutenblog_settings_typography_h6',

        'gutenblog_setting_typography_text_color',
        'gutenblog_setting_typography_h1_color',
        'gutenblog_setting_typography_h2_color',
        'gutenblog_setting_typography_h3_color',
        'gutenblog_setting_typography_h4_color',
        'gutenblog_setting_typography_h5_color',
        'gutenblog_setting_typography_h6_color',

        'gutenblog_section_appearance_border_radius_select',
    );
    foreach ($fields_names as $key => $value) {
    	if(function_exists('gutenblog_get_option')){

        	$f = gutenblog_get_option($value);

	        $all_fields[$key]['value'] = $f;
	        $element = "";
	        if($value == "gutenblog_settings_typography_menu"){
	            $element = ".menu-item";
	        } else if($value == "gutenblog_settings_typography_post_title"){
	            // $element = ".gutenblog-blog-feed-post .entry-title,
	            //               .frontpage-featured-posts .entry-title,
	            //               .widget .entry-title,
	            //               .rpwwt-post-title,
	            //               .widget_socialcountplus .social-count-plus .count";

	            // $element = ".editor-post-title__block .editor-post-title__input";
                $element = ".fake-titile-gutenberg";
	        } else if($value == "gutenblog_settings_typography_body_font"){
	            $element = "body, pre";
	        } else if($value == "gutenblog_settings_typography_pre_code"){
                $element = '[data-type="core/preformatted"] pre';
            } else if($value == "gutenblog_settings_typography_h1"){
	            $element = "h1, .editor-post-title__block .editor-post-title__input";
	        } else if($value == "gutenblog_settings_typography_h2"){
	            $element = "h2";
	        } else if($value == "gutenblog_settings_typography_h3"){
	            $element = "h3";
	        } else if($value == "gutenblog_settings_typography_h4"){
	            $element = "h4";
	        } else if($value == "gutenblog_settings_typography_h5"){
	            $element = "h5";
	        } else if($value == "gutenblog_settings_typography_h6"){
	            $element = "h6";
	        } else if($value == "gutenblog_setting_typography_h1_color"){
                $element = "h1, .h1, .editor-post-title__block .editor-post-title__input, .wp-block-cover h1";
            } else if($value == "gutenblog_setting_typography_h2_color"){
                $element = "h2, .h2, .wp-block-cover h2";
            } else if($value == "gutenblog_setting_typography_h3_color"){
                $element = "h3, .h3, .wp-block-cover h3";
            } else if($value == "gutenblog_setting_typography_h4_color"){
                $element = "h4, .h4, .wp-block-cover h4";
            } else if($value == "gutenblog_setting_typography_h5_color"){
                $element = "h5, .h5, .wp-block-cover h5";
            } else if($value == "gutenblog_setting_typography_h6_color"){
                $element = "h6, .h6, .wp-block-cover h6";
            } else if($value == "gutenblog_setting_typography_text_color"){
                $element = "body, pre,
                            a, a:hover, a:visited, a:active, a:focus,
                            .wp-block-quote__citation, .wp-block-quote cite, .wp-block-quote footer,
                            .wp-block-audio figcaption,
                            .wp-block-pullquote,
                            .wp-block-pullquote__citation, .wp-block-pullquote cite, .wp-block-pullquote footer,
                            .wp-block-image figcaption,
                            .wp-block-embed figcaption";
            } else if($value == "gutenblog_section_appearance_border_radius_select"){

                $element = '.wp-block-image img,
                            .post-categories li a,
                            .entry-thumb,
                            .entry-thumb iframe,
                            .wp-block-cover.has-background-dim,
                            img,
                            .form-control,
                            input[type="text"],
                            input[type="email"],
                            input[type="password"],
                            input[type="url"],
                            input[type="date"],
                            textarea:not(.editor-post-title__input),
                            select,
                            .btn,
                            input[type="submit"],
                            input[type="reset"],
                            .recentcomments,
                            .comment-form,
                            .comment-form textarea.form-control';

                $all_fields[$key]['style'] = "border-radius";
            }

            if($element != ""){
    	        $all_fields[$key]['element'] = $element;
            }
        }
    }
    
    if(function_exists('gutenblog_output_custom_font')){
    	return gutenblog_output_custom_font($all_fields, true);
  	}  else {
  		return '';
  	}
}

?>