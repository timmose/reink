<?php
/*
Name:  WordPress Post View System
Description:  A simple and efficient post view system for WordPress.
Version:      1.0
Author:       
Author URI:   
License:
Copyright (C) 
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

function get_post_views($postID, $only_number = false, $only_text = false) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        if($only_number == true && $only_text == false){
            return "0";
        } else if($only_number == false && $only_text == true){
            return "0 ".__( 'View', 'themes-monsters' );
        } else { // with html
            return '<div class="views-wrap">
                <span class="views-icon icon-eye"></span>
                <span class="views-label">0</span>
            </div>';
        }
    }

    if($only_number == true && $only_text == false){
        return $count; 
    } else if($only_number == false && $only_text == true){
        return $count.' '.__( 'Views', 'themes-monsters' ); 
    } else { // with html
        return '<div class="views-wrap align-self-center">
            <span class="views-icon icon-eye"></span>
            <span class="views-label">'.$count.'</span>
        </div>';
    }
}

function set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
// Remove issues with prefetching adding extra views
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

?>