<?php
/*
Plugin Name: ZoxPress Plugin
Description: Plugin containing features for use with ZoxPress WordPress theme
Author: MVP Themes
Author URI: https://themeforest.net/user/mvpthemes/portfolio
Version: 1.01.0
*/


require_once(__DIR__ . '/widgets/widget-ad.php');
require_once(__DIR__ . '/widgets/widget-facebook.php');
require_once(__DIR__ . '/widgets/widget-feat.php');
require_once(__DIR__ . '/widgets/widget-featlist.php');
require_once(__DIR__ . '/widgets/widget-flex1.php');
require_once(__DIR__ . '/widgets/widget-altimg.php');
require_once(__DIR__ . '/widgets/widget-side-tab.php');
require_once(__DIR__ . '/widgets/widget-side-trend.php');


function zox_meta_head() { ?>
	<meta name="theme-color" content="<?php $zox_skin = get_option('zox_skin'); $zox_bot_nav_bg = get_option('zox_bot_nav_bg');
		if ($zox_skin == "2" || $zox_skin == "4" || $zox_skin == "7" || $zox_skin == "11" || $zox_skin == "12" || $zox_skin == "13" || $zox_skin == "15" || $zox_skin == "16") {
			echo esc_html("#fff");
		} else if ($zox_skin == "3" || $zox_skin == "9" || $zox_skin == "10" || $zox_skin == "14") {
			echo esc_html("#000");
		} else if ($zox_skin == "5") {
			echo esc_html("#23001b");
		} else if ($zox_skin == "6") {
			echo esc_html("#102039");
		} else if ($zox_skin == "8") {
			echo esc_html("#013369");
		} else if ($zox_skin == "1") {
			echo esc_html($zox_bot_nav_bg);
		} else {
			echo esc_html("#fff");
	}?>" />
	<?php if ( is_single() ) { ?>
		<meta property="og:type" content="article" />
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>
				<?php global $post; $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'zox-large-thumb' ); ?>
				<meta property="og:image" content="<?php echo esc_url( $thumb['0'] ); ?>" />
				<meta name="twitter:image" content="<?php echo esc_url( $thumb['0'] ); ?>" />
			<?php } ?>
			<meta property="og:url" content="<?php the_permalink() ?>" />
			<meta property="og:title" content="<?php the_title_attribute(); ?>" />
			<meta property="og:description" content="<?php echo strip_tags(get_the_excerpt()); ?>" />
			<meta name="twitter:card" content="summary">
			<meta name="twitter:url" content="<?php the_permalink() ?>">
			<meta name="twitter:title" content="<?php the_title_attribute(); ?>">
			<meta name="twitter:description" content="<?php echo strip_tags(get_the_excerpt()); ?>">
		<?php endwhile; endif; ?>
	<?php } else { ?>
		<meta property="og:description" content="<?php bloginfo('description'); ?>" />
	<?php } ?>
<?php }
add_action( 'wp_head', 'zox_meta_head' );

/////////////////////////////////////
// Add Custom Meta Box
/////////////////////////////////////

/* Fire our meta box setup function on the post editor screen. */
add_action( 'load-post.php', 'zox_post_meta_boxes_setup' );
add_action( 'load-post-new.php', 'zox_post_meta_boxes_setup' );

/* Meta box setup function. */
if ( !function_exists( 'zox_post_meta_boxes_setup' ) ) {
function zox_post_meta_boxes_setup() {

	/* Add meta boxes on the 'add_meta_boxes' hook. */
	add_action( 'add_meta_boxes', 'zox_add_post_meta_boxes' );

	/* Save post meta on the 'save_post' hook. */
	add_action( 'save_post', 'zox_save_video_embed_meta', 10, 2 );
	add_action( 'save_post', 'zox_save_featured_headline_meta', 10, 2 );
	add_action( 'save_post', 'zox_save_post_template_meta', 10, 2 );
	add_action( 'save_post', 'zox_save_post_alp_meta', 10, 2 );
	add_action( 'save_post', 'zox_save_featured_image_meta', 10, 2 );
	add_action( 'save_post', 'zox_save_post_side_meta', 10, 2 );
}
}

/* Create one or more meta boxes to be displayed on the post editor screen. */
if ( !function_exists( 'zox_add_post_meta_boxes' ) ) {
function zox_add_post_meta_boxes() {

	add_meta_box(
		'zox-video-embed',			// Unique ID
		esc_html__( 'Video/Audio Embed', 'zoxpress' ),		// Title
		'zox_video_embed_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'normal',				// Context
		'high'					// Priority
	);

	add_meta_box(
		'zox-featured-headline',			// Unique ID
		esc_html__( 'Featured Headline', 'zoxpress' ),		// Title
		'zox_featured_headline_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'normal',				// Context
		'high'					// Priority
	);

	add_meta_box(
		'zox-post-template',			// Unique ID
		esc_html__( 'Post Template', 'zoxpress' ),		// Title
		'zox_post_template_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'side',					// Context
		'core'					// Priority
	);

	add_meta_box(
		'zox-post-alp',			// Unique ID
		esc_html__( 'Auto Load Posts', 'zoxpress' ),		// Title
		'zox_post_alp_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'side',					// Context
		'core'					// Priority
	);

	add_meta_box(
		'zox-featured-image',			// Unique ID
		esc_html__( 'Featured Image Show/Hide', 'zoxpress' ),		// Title
		'zox_featured_image_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'side',					// Context
		'core'					// Priority
	);

	add_meta_box(
		'zox-post-side',			// Unique ID
		esc_html__( 'Post Sidebar Show/Hide', 'zoxpress' ),		// Title
		'zox_post_side_meta_box',		// Callback function
		'post',					// Admin page (or post type)
		'side',					// Context
		'core'					// Priority
	);

}
}

/* Display the post meta box. */
if ( !function_exists( 'zox_video_embed_meta_box' ) ) {
function zox_video_embed_meta_box( $object, $box ) { ?>

	<?php wp_nonce_field( 'zox_save_video_embed_meta', 'zox_video_embed_nonce' ); ?>

	<p>
		<label for="zox-video-embed"><?php esc_html_e( "Enter your video or audio embed code.", 'zoxpress' ); ?></label>
		<br />
		<input class="widefat" type="text" name="zox-video-embed" id="zox-video-embed" value="<?php echo esc_html( get_post_meta( $object->ID, 'zox_video_embed', true ) ); ?>" />
	</p>

<?php }
}

/* Display the post meta box. */
if ( !function_exists( 'zox_featured_headline_meta_box' ) ) {
function zox_featured_headline_meta_box( $object, $box ) { ?>

	<?php wp_nonce_field( 'zox_save_featured_headline_meta', 'zox_featured_headline_nonce' ); ?>

	<p>
		<label for="zox-featured-headline"><?php esc_html_e( "Add a custom featured headline that will be displayed in the featured slider.", 'zoxpress' ); ?></label>
		<br />
		<input class="widefat" type="text" name="zox-featured-headline" id="zox-featured-headline" value="<?php echo esc_html( get_post_meta( $object->ID, 'zox_featured_headline', true ) ); ?>" size="30" />
	</p>

<?php }
}

/* Display the post meta box. */
if ( !function_exists( 'zox_post_template_meta_box' ) ) {
function zox_post_template_meta_box( $object, $box ) { ?>

	<?php wp_nonce_field( 'zox_save_post_template_meta', 'zox_post_template_nonce' ); $selected = esc_html( get_post_meta( $object->ID, 'zox_post_template', true ) ); ?>

	<p>
		<label for="zox-post-template"><?php esc_html_e( "Select a template for your post, or use the global setting within the Theme Options.", 'zoxpress' ); ?></label>
		<br /><br />
		<select class="widefat" name="zox-post-template" id="zox-post-template">
			<option value="global" <?php selected( $selected, 'global' ); ?>>Use Global Setting</option>
			<option value="temp1" <?php selected( $selected, 'temp1' ); ?>>Template 1</option>
			<option value="temp2" <?php selected( $selected, 'temp2' ); ?>>Template 2</option>
			<option value="temp3" <?php selected( $selected, 'temp3' ); ?>>Template 3</option>
			<option value="temp4" <?php selected( $selected, 'temp4' ); ?>>Template 4</option>
			<option value="temp5" <?php selected( $selected, 'temp5' ); ?>>Template 5</option>
			<option value="temp6" <?php selected( $selected, 'temp6' ); ?>>Template 6</option>
			<option value="temp7" <?php selected( $selected, 'temp7' ); ?>>Template 7</option>
        	</select>
	</p>
<?php }
}

/* Display the post meta box. */
if ( !function_exists( 'zox_post_alp_meta_box' ) ) {
function zox_post_alp_meta_box( $object, $box ) { ?>
	<?php wp_nonce_field( 'zox_save_post_alp_meta', 'zox_post_alp_nonce' ); $selected = esc_html( get_post_meta( $object->ID, 'zox_post_alp', true ) ); ?>
	<p>
		<label for="zox-post-alp"><?php esc_html_e( "Select whether to enable Auto Load Posts on this post, or use the global setting within the Theme Options.", 'zoxpress' ); ?></label>
		<br /><br />
		<select class="widefat" name="zox-post-alp" id="zox-post-alp">
			<option value="global" <?php selected( $selected, 'global' ); ?>>Use Global Setting</option>
			<option value="on" <?php selected( $selected, 'on' ); ?>>On</option>
			<option value="off" <?php selected( $selected, 'off' ); ?>>Off</option>
        </select>
	</p>
<?php }
}

/* Display the post meta box. */
if ( !function_exists( 'zox_featured_image_meta_box' ) ) {
function zox_featured_image_meta_box( $object, $box ) { ?>

	<?php wp_nonce_field( 'zox_save_featured_image_meta', 'zox_featured_image_nonce' ); $selected = esc_html( get_post_meta( $object->ID, 'zox_featured_image', true ) ); ?>

	<p>
		<label for="zox-featured-image"><?php esc_html_e( "Select to show or hide the featured image from automatically displaying in this post, or use the global setting within the Theme Options.", 'zoxpress' ); ?></label>
		<br /><br />
		<select class="widefat" name="zox-featured-image" id="zox-featured-image">
			<option value="global" <?php selected( $selected, 'global' ); ?>>Use Global Setting</option>
            <option value="show" <?php selected( $selected, 'show' ); ?>>Show</option>
            <option value="hide" <?php selected( $selected, 'hide' ); ?>>Hide</option>
        </select>
	</p>
<?php }
}

/* Display the post meta box. */
if ( !function_exists( 'zox_post_side_meta_box' ) ) {
function zox_post_side_meta_box( $object, $box ) { ?>

	<?php wp_nonce_field( 'zox_save_post_side_meta', 'zox_post_side_nonce' ); $selected = esc_html( get_post_meta( $object->ID, 'zox_post_side', true ) ); ?>

	<p>
		<label for="zox-post-side"><?php esc_html_e( "Select to show or hide the sidebar for this post, or use the global setting within the Theme Options..", 'zoxpress' ); ?></label>
		<br /><br />
		<select class="widefat" name="zox-post-side" id="zox-post-side">
			<option value="global" <?php selected( $selected, 'global' ); ?>>Use Global Setting</option>
           	<option value="show" <?php selected( $selected, 'show' ); ?>>Show</option>
            <option value="hide" <?php selected( $selected, 'hide' ); ?>>Hide</option>
        </select>
	</p>
<?php }
}

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_video_embed_meta' ) ) {
function zox_save_video_embed_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_video_embed_nonce'] ) || !wp_verify_nonce( $_POST['zox_video_embed_nonce'], 'zox_save_video_embed_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-video-embed'] ) ? balanceTags( html_entity_decode( $_POST['zox-video-embed'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_video_embed';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_featured_headline_meta' ) ) {
function zox_save_featured_headline_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_featured_headline_nonce'] ) || !wp_verify_nonce( $_POST['zox_featured_headline_nonce'], 'zox_save_featured_headline_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-featured-headline'] ) ? balanceTags( html_entity_decode( $_POST['zox-featured-headline'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_featured_headline';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_post_template_meta' ) ) {
function zox_save_post_template_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_post_template_nonce'] ) || !wp_verify_nonce( $_POST['zox_post_template_nonce'], 'zox_save_post_template_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-post-template'] ) ? balanceTags( html_entity_decode( $_POST['zox-post-template'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_post_template';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_post_alp_meta' ) ) {
function zox_save_post_alp_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_post_alp_nonce'] ) || !wp_verify_nonce( $_POST['zox_post_alp_nonce'], 'zox_save_post_alp_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-post-alp'] ) ? balanceTags( html_entity_decode( $_POST['zox-post-alp'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_post_alp';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_featured_image_meta' ) ) {
function zox_save_featured_image_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_featured_image_nonce'] ) || !wp_verify_nonce( $_POST['zox_featured_image_nonce'], 'zox_save_featured_image_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-featured-image'] ) ? balanceTags( html_entity_decode( $_POST['zox-featured-image'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_featured_image';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }

/* Save the meta box's post metadata. */
if ( !function_exists( 'zox_save_post_side_meta' ) ) {
function zox_save_post_side_meta( $post_id, $post ) {

	/* Verify the nonce before proceeding. */
	if ( !isset( $_POST['zox_post_side_nonce'] ) || !wp_verify_nonce( $_POST['zox_post_side_nonce'], 'zox_save_post_side_meta' ) )
		return $post_id;

	/* Get the post type object. */
	$post_type = get_post_type_object( $post->post_type );

	/* Check if the current user has permission to edit the post. */
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;

	/* Get the posted data and sanitize it for use as an HTML class. */
	$new_meta_value = ( isset( $_POST['zox-post-side'] ) ? balanceTags( html_entity_decode( $_POST['zox-post-side'] ) ) : '' );

	/* Get the meta key. */
	$meta_key = 'zox_post_side';

	/* Get the meta value of the custom field key. */
	$meta_value = get_post_meta( $post_id, $meta_key, true );

	/* If a new meta value was added and there was no previous value, add it. */
	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, $meta_key, $new_meta_value, true );

	/* If the new meta value does not match the old value, update it. */
	elseif ( $new_meta_value && $new_meta_value != $meta_value )
		update_post_meta( $post_id, $meta_key, $new_meta_value );

	/* If there is no new meta value but an old value exists, delete it. */
	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, $meta_key, $meta_value );
} }


/////////////////////////////////////
// Auto Load Posts and Social Buttons
/////////////////////////////////////

require_once(__DIR__ . '/config.php');
$Plugin = new \AutoLoadPosts\Plugin();
$Plugin->Init();

 if ( !function_exists( 'zox_SocialScroll' ) ) {
 function zox_SocialScroll() {
  { ?>
 	<div class="zox-post-soc-scroll">
 		<ul class="zox-post-soc-list left zoxrel">
 			<a href="#" onclick="window.open('http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title_attribute(); ?>', 'facebookShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Facebook', 'zox-news' ); ?>">
 			<li class="zox-post-soc-fb">
 				<i class="fab fa-facebook-f"></i>
 			</li>
 			</a>
 			<a href="#" onclick="window.open('http://twitter.com/share?text=<?php the_title_attribute(); ?> -&amp;url=<?php the_permalink() ?>', 'twitterShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Tweet This Post', 'zox-news' ); ?>">
 			<li class="zox-post-soc-twit">
 				<i class="fab fa-twitter"></i>
 			</li>
 			</a>
 			<a href="#" onclick="window.open('https://share.flipboard.com/bookmarklet/popout?v=<?php the_title_attribute(); ?>&url=<?php the_permalink();?>&utm_medium=article-share&utm_campaign=tools&utm_source=<?php echo get_bloginfo( 'name' ); ?>', 'flipboardShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Flipboard', 'zox-news' ); ?>">
 			<li class="zox-post-soc-flip">
 				<i class="fab fa-flipboard"></i>
 			</li>
 			</a>
 			<a href="mailto:?subject=<?php the_title_attribute(); ?>&amp;BODY=<?php esc_html_e( 'I found this article interesting and thought of sharing it with you. Check it out:', 'zox-news' ); ?> <?php the_permalink(); ?>">
 			<li class="zox-post-soc-email">
 				<i class="fas fa-envelope"></i>
 			</li>
 			</a>
 			<?php if ( comments_open() ) { ?>
 				<?php $disqus_id = get_option('zox_disqus_id'); if ($disqus_id) { if (isset($disqus_id)) {  ?>
 					<a href="#disqus_thread">
 					<li class="zox-post-soc-com zox-com-click">
 						<i class="far fa-comment"></i>
 					</li>
 					</a>
 				<?php } } else { ?>
 					<a href="<?php comments_link(); ?>">
 					<li class="zox-post-soc-com zox-com-click">
 						<i class="far fa-comment"></i>
 					</li>
 					</a>
 				<?php } ?>
 			<?php } ?>
 		</ul>
 	</div><!--zox-post-soc-scroll-->
 	<div class="zox-soc-mob-wrap">
 		<div class="zox-soc-mob-left left relative">
 			<ul class="zox-soc-mob-list left relative">
 				<a href="#" onclick="window.open('http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title_attribute(); ?>', 'facebookShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Facebook', 'zox-news' ); ?>">
 				<li class="zox-soc-mob-fb">
 					<i class="fab fa-facebook-f"></i><span class="zox-soc-mob-fb"><?php esc_html_e( "Share", 'zox-news' ); ?></span>
 				</li>
 				</a>
 				<a href="#" onclick="window.open('http://twitter.com/share?text=<?php the_title_attribute(); ?> -&amp;url=<?php the_permalink() ?>', 'twitterShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Tweet This Post', 'zox-news' ); ?>">
 				<li class="zox-soc-mob-twit">
 					<i class="fab fa-twitter"></i><span class="zox-soc-mob-fb"><?php esc_html_e( "Tweet", 'zox-news' ); ?></span>
 				</li>
 				</a>
 				<a href="#" onclick="window.open('https://share.flipboard.com/bookmarklet/popout?v=<?php the_title_attribute(); ?>&url=<?php the_permalink();?>&utm_medium=article-share&utm_campaign=tools&utm_source=<?php echo get_bloginfo( 'name' ); ?>', 'flipboardShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Flipboard', 'zox-news' ); ?>">
 				<li class="zox-soc-mob-flip">
 					<i class="fab fa-flipboard"></i>
 				</li>
 				</a>
 				<a href="whatsapp://send?text=<?php the_title(); ?> <?php the_permalink() ?>">
 				<li class="zox-soc-mob-what">
 					<i class="fab fa-whatsapp"></i>
 				</li>
 				</a>
 				<a href="mailto:?subject=<?php the_title_attribute(); ?>&amp;BODY=<?php esc_html_e( 'I found this article interesting and thought of sharing it with you. Check it out:', 'zox-news' ); ?> <?php the_permalink(); ?>">
 				<li class="zox-soc-mob-email">
 					<i class="fas fa-envelope"></i>
 				</li>
 				</a>
 				<?php if ( comments_open() ) { ?>
 					<?php $disqus_id = get_option('zox_disqus_id'); if ($disqus_id) { if (isset($disqus_id)) {  ?>
 						<a href="#disqus_thread">
 						<li class="zox-soc-mob-com zox-com-click">
 							<i class="fas fa-comment"></i>
 						</li>
 						</a>
 					<?php } } else { ?>
 						<a href="<?php comments_link(); ?>">
 						<li class="zox-soc-mob-com zox-com-click">
 							<i class="fas fa-comment"></i>
 						</li>
 						</a>
 					<?php } ?>
 				<?php } ?>
 			</ul>
 		</div><!--zox-soc-mob-left-->
 		<div class="zox-soc-mob-right left relative zox-mob-soc-click">
 			<i class="fas fa-ellipsis-h" aria-hidden="true"></i>
 		</div><!--zox-soc-mob-right-->
 	</div><!--zox-soc-mob-wrap-->
 <?php }
 }
 }

 if ( !function_exists( 'zox_SocialStat' ) ) {
 function zox_SocialStat() {
  { ?>
	<div class="zox-post-soc-stat">
		<ul class="zox-post-soc-stat-list left zoxrel">
 			<a href="#" onclick="window.open('http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title_attribute(); ?>', 'facebookShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Facebook', 'zox-news' ); ?>">
 			<li class="zox-post-soc-fb">
 				<i class="fab fa-facebook-f"></i>
 			</li>
 			</a>
 			<a href="#" onclick="window.open('http://twitter.com/share?text=<?php the_title_attribute(); ?> -&amp;url=<?php the_permalink() ?>', 'twitterShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Tweet This Post', 'zox-news' ); ?>">
 			<li class="zox-post-soc-twit">
 				<i class="fab fa-twitter"></i>
 			</li>
 			</a>
 			<a href="#" onclick="window.open('https://share.flipboard.com/bookmarklet/popout?v=<?php the_title_attribute(); ?>&url=<?php the_permalink();?>&utm_medium=article-share&utm_campaign=tools&utm_source=<?php echo get_bloginfo( 'name' ); ?>', 'flipboardShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Flipboard', 'zox-news' ); ?>">
 			<li class="zox-post-soc-flip">
 				<i class="fab fa-flipboard"></i>
 			</li>
 			</a>
 			<a href="mailto:?subject=<?php the_title_attribute(); ?>&amp;BODY=<?php esc_html_e( 'I found this article interesting and thought of sharing it with you. Check it out:', 'zox-news' ); ?> <?php the_permalink(); ?>">
 			<li class="zox-post-soc-email">
 				<i class="fas fa-envelope"></i>
 			</li>
 			</a>
 			<?php if ( comments_open() ) { ?>
 				<?php $disqus_id = get_option('zox_disqus_id'); if ($disqus_id) { if (isset($disqus_id)) {  ?>
 					<a href="#disqus_thread">
 					<li class="zox-post-soc-com zox-com-click">
 						<i class="far fa-comment"></i>
 					</li>
 					</a>
 				<?php } } else { ?>
 					<a href="<?php comments_link(); ?>">
 					<li class="zox-post-soc-com zox-com-click">
 						<i class="far fa-comment"></i>
 					</li>
 					</a>
 				<?php } ?>
 			<?php } ?>
 		</ul>
	</div><!--zox-post-soc-stat-->
 <?php }
 }
 }

 if ( !function_exists( 'zox_SocialALP' ) ) {
 function zox_SocialALP() {
 { ?>
 	<div class="zox-alp-soc-wrap">
 		<ul class="zox-alp-soc-list">
 			<a href="#" onclick="window.open('http://www.facebook.com/sharer.php?u=<?php global $post; the_permalink($post->ID);?>&amp;t=<?php the_title_attribute(array('post'=>$post->ID)); ?>', 'facebookShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Facebook', 'zoxpress' ); ?>">
 				<li class="zox-alp-soc-fb"><span class="fab fa-facebook-f"></span></li>
 			</a>
 			<a href="#" onclick="window.open('http://twitter.com/share?text=<?php global $post; the_title_attribute(array('post'=>$post->ID)); ?> &amp;url=<?php the_permalink($post->ID) ?>', 'twitterShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Tweet This Post', 'zoxpress' ); ?>">
 				<li class="zox-alp-soc-twit"><span class="fab fa-twitter"></span></li>
 			</a>
 			<a href="#" onclick="window.open('https://share.flipboard.com/bookmarklet/popout?v=<?php the_title_attribute(); ?>&url=<?php the_permalink();?>&utm_medium=article-share&utm_campaign=tools&utm_source=<?php echo get_bloginfo( 'name' ); ?>', 'flipboardShare', 'width=626,height=436'); return false;" title="<?php esc_html_e( 'Share on Flipboard', 'zox-news' ); ?>">
 				<li class="zox-alp-soc-flip"><span class="fab fa-flipboard"></span></li>
 			</a>
 			<a href="mailto:?subject=<?php global $post; the_title_attribute(array('post'=>$post->ID)); ?>&amp;BODY=<?php esc_html_e( 'I found this article interesting and thought of sharing it with you. Check it out:', 'zoxpress' ); ?> <?php the_permalink($post->ID); ?>">
 				<li class="zox-alp-soc-com"><span class="fas fa-envelope"></span></li>
 			</a>
 		</ul>
 	</div>
 <?php }
 }
 }

 if ( !function_exists( 'zox_new_contactmethods' ) ) {
 function zox_new_contactmethods( $contactmethods ) {
     $contactmethods['facebook'] = 'Facebook'; // Add Facebook
     $contactmethods['twitter'] = 'Twitter'; // Add Twitter
	 $contactmethods['instagram'] = 'Instagram'; // Add Instagram
     $contactmethods['flipboard'] = 'Flipboard'; // Add Flipboard
     $contactmethods['youtube'] = 'Youtube'; // Add Youtube
     $contactmethods['linkedin'] = 'LinkedIn'; // Add LinkedIn
     $contactmethods['pinterest'] = 'Pinterest'; // Add Pinterest
     $contactmethods['tumblr'] = 'Tumblr'; // Add Tumblr

     return $contactmethods;
 }
 }
add_filter('user_contactmethods','zox_new_contactmethods',10,1);

 ?>