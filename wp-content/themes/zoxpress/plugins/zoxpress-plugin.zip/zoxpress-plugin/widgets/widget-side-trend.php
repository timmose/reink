<?php
add_action( 'widgets_init', 'zox_side_trend_load_widgets' );

function zox_side_trend_load_widgets() {
	register_widget( 'zox_side_trend_widget' );
}

class zox_side_trend_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function __construct() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'zox_side_trend_widget', 'description' => esc_html__('A widget that displays a set number of Trending Posts for use in sidebar widget areas.', 'zoxpress') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'zox_side_trend_widget' );

		/* Create the widget. */
		parent::__construct( 'zox_side_trend_widget', esc_html__('ZoxPress: Sidebar Trending Widget', 'zoxpress'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		global $post;
		$title = apply_filters('widget_title', $instance['title'] );
		$popular_days = $instance['popular_days'];
		$number = $instance['number'];

		/* Before widget (defined by themes). */
		echo html_entity_decode($before_widget);

		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo html_entity_decode($before_title . $title . $after_title);

		?>

			<div class="zox-widget-side-trend-wrap left zoxrel zox100">
				<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
					<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
						<?php get_template_part( 'parts/art', 'small' ); ?>
					<?php endwhile; wp_reset_postdata(); ?>
				<?php } else { ?>
					<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
						<?php get_template_part( 'parts/art', 'small' ); ?>
					<?php endwhile; wp_reset_postdata(); ?>
				<?php } ?>
			</div><!--zox-widget-side-trend-wrap-->

		<?php

		/* After widget (defined by themes). */
		echo html_entity_decode($after_widget);

	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['popular_days'] = strip_tags( $new_instance['popular_days'] );
		$instance['number'] = strip_tags( $new_instance['number'] );

		return $instance;
	}


	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'title' => 'Trending', 'popular_days' => '30', 'number' => '5' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'title' )); ?>">Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" style="width:90%;" />
		</p>

		<!-- Number of days -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'popular_days' )); ?>">Number of days to use for Trending Posts:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'popular_days' )); ?>" name="<?php echo esc_html($this->get_field_name( 'popular_days' )); ?>" value="<?php echo esc_html($instance['popular_days']); ?>" size="3" />
		</p>

		<!-- Number of posts -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'number' )); ?>">Number of Trending Posts to display:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'number' )); ?>" name="<?php echo esc_html($this->get_field_name( 'number' )); ?>" value="<?php echo esc_html($instance['number']); ?>" size="3" />
		</p>

	<?php
	}
}

?>